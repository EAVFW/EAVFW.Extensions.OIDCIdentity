﻿using Kjeldager.Models;
using System;
using EAVFramework.Shared;
using System.Runtime.Serialization;
using Newtonsoft.Json;
using System.Text.Json.Serialization;
using System.ComponentModel.DataAnnotations.Schema;
using System.Collections.Generic;
using EAVFW.Extensions.OIDCIdentity;

namespace Kjeldager.Models
{
	[Serializable()]
	[Entity(LogicalName="openidconnectclient",SchemaName="OpenIdConnectClient",CollectionSchemaName="OpenIdConnectClients",IsBaseClass=false)]
	[EntityDTO(LogicalName="openidconnectclient",Schema="Kjeldager")]
	public partial class OpenIdConnectClient : Identity, IOpenIdConnectClient<AllowedGrantType, OpenIdConnectClientTypes, OpenIdConnectClientConsentTypes, AllowedGrantTypeValue>
	{
		public OpenIdConnectClient()
		{
		}

		[DataMember(Name="description")]
		[JsonProperty("description")]
		[JsonPropertyName("description")]
		public String Description {get;set;}

		[DataMember(Name="clienturi")]
		[JsonProperty("clienturi")]
		[JsonPropertyName("clienturi")]
		public String ClientUri {get;set;}

		[DataMember(Name="logouri")]
		[JsonProperty("logouri")]
		[JsonPropertyName("logouri")]
		public String LogoUri {get;set;}

		[DataMember(Name="requireconsent")]
		[JsonProperty("requireconsent")]
		[JsonPropertyName("requireconsent")]
		public Boolean? RequireConsent {get;set;}

		[DataMember(Name="allowrememberconsent")]
		[JsonProperty("allowrememberconsent")]
		[JsonPropertyName("allowrememberconsent")]
		public Boolean? AllowRememberConsent {get;set;}

		[DataMember(Name="enablelocallogin")]
		[JsonProperty("enablelocallogin")]
		[JsonPropertyName("enablelocallogin")]
		public Boolean? EnableLocalLogin {get;set;}

		[DataMember(Name="identityproviderrestrictions")]
		[JsonProperty("identityproviderrestrictions")]
		[JsonPropertyName("identityproviderrestrictions")]
		public String IdentityProviderRestrictions {get;set;}

		[DataMember(Name="allowofflineaccess")]
		[JsonProperty("allowofflineaccess")]
		[JsonPropertyName("allowofflineaccess")]
		public Boolean? AllowOfflineAccess {get;set;}

		[DataMember(Name="pairwisesubjectsalt")]
		[JsonProperty("pairwisesubjectsalt")]
		[JsonPropertyName("pairwisesubjectsalt")]
		public String PairWiseSubjectSalt {get;set;}

		[DataMember(Name="requirepkce")]
		[JsonProperty("requirepkce")]
		[JsonPropertyName("requirepkce")]
		public Boolean? RequirePKCE {get;set;}

		[DataMember(Name="allowplaintextpkce")]
		[JsonProperty("allowplaintextpkce")]
		[JsonPropertyName("allowplaintextpkce")]
		public Boolean? AllowPlainTextPKCE {get;set;}

		[DataMember(Name="requirerequestobject")]
		[JsonProperty("requirerequestobject")]
		[JsonPropertyName("requirerequestobject")]
		public Boolean? RequireRequestObject {get;set;}

		[DataMember(Name="allowaccesstokensviabrowser")]
		[JsonProperty("allowaccesstokensviabrowser")]
		[JsonPropertyName("allowaccesstokensviabrowser")]
		public Boolean? AllowAccessTokensViaBrowser {get;set;}

		[DataMember(Name="status")]
		[JsonProperty("status")]
		[JsonPropertyName("status")]
		public OpenIdConnectClientStatus? Status {get;set;}

		[DataMember(Name="protocoltype")]
		[JsonProperty("protocoltype")]
		[JsonPropertyName("protocoltype")]
		public ProtocolTypes? ProtocolType {get;set;}

		[DataMember(Name="requireclientsecret")]
		[JsonProperty("requireclientsecret")]
		[JsonPropertyName("requireclientsecret")]
		public Boolean? RequireClientSecret {get;set;}

		[DataMember(Name="clientid")]
		[JsonProperty("clientid")]
		[JsonPropertyName("clientid")]
		public String ClientId {get;set;}

		[DataMember(Name="clientsecret")]
		[JsonProperty("clientsecret")]
		[JsonPropertyName("clientsecret")]
		public String ClientSecret {get;set;}

		[DataMember(Name="consenttype")]
		[JsonProperty("consenttype")]
		[JsonPropertyName("consenttype")]
		public OpenIdConnectClientConsentTypes? ConsentType {get;set;}

		[DataMember(Name="type")]
		[JsonProperty("type")]
		[JsonPropertyName("type")]
		public OpenIdConnectClientTypes? Type {get;set;}

		[DataMember(Name="redirecturis")]
		[JsonProperty("redirecturis")]
		[JsonPropertyName("redirecturis")]
		public String RedirectUris {get;set;}

		[DataMember(Name="postlogoutredirecturis")]
		[JsonProperty("postlogoutredirecturis")]
		[JsonPropertyName("postlogoutredirecturis")]
		public String PostLogoutRedirectURIs {get;set;}

		[DataMember(Name="frontchannellogouturi")]
		[JsonProperty("frontchannellogouturi")]
		[JsonPropertyName("frontchannellogouturi")]
		public String FrontChannelLogoutURI {get;set;}

		[DataMember(Name="includejwtid")]
		[JsonProperty("includejwtid")]
		[JsonPropertyName("includejwtid")]
		public Boolean? IncludeJWTId {get;set;}

		[DataMember(Name="claims")]
		[JsonProperty("claims")]
		[JsonPropertyName("claims")]
		public String Claims {get;set;}

		[DataMember(Name="alwayssendclientclaims")]
		[JsonProperty("alwayssendclientclaims")]
		[JsonPropertyName("alwayssendclientclaims")]
		public Boolean? AlwaysSendClientClaims {get;set;}

		[DataMember(Name="clientclaimsprefix")]
		[JsonProperty("clientclaimsprefix")]
		[JsonPropertyName("clientclaimsprefix")]
		public String ClientCLaimsPrefix {get;set;}

		[DataMember(Name="userssolifetime")]
		[JsonProperty("userssolifetime")]
		[JsonPropertyName("userssolifetime")]
		public Int32? UserSSOLifetime {get;set;}

		[DataMember(Name="usercodetype")]
		[JsonProperty("usercodetype")]
		[JsonPropertyName("usercodetype")]
		public String UserCodeType {get;set;}

		[DataMember(Name="devicecodelifetime")]
		[JsonProperty("devicecodelifetime")]
		[JsonPropertyName("devicecodelifetime")]
		public Int32? DeviceCodeLifetime {get;set;}

		[DataMember(Name="allowedcorsorigins")]
		[JsonProperty("allowedcorsorigins")]
		[JsonPropertyName("allowedcorsorigins")]
		public String AllowedCORSOrigins {get;set;}

		[DataMember(Name="frontchannellogoutsessionrequired")]
		[JsonProperty("frontchannellogoutsessionrequired")]
		[JsonPropertyName("frontchannellogoutsessionrequired")]
		public Boolean? FrontChannelLogoutSessionRequired {get;set;}

		[DataMember(Name="backchannellogouturi")]
		[JsonProperty("backchannellogouturi")]
		[JsonPropertyName("backchannellogouturi")]
		public String BackChannelLogoutURI {get;set;}

		[DataMember(Name="backchannellogoutsessionrequired")]
		[JsonProperty("backchannellogoutsessionrequired")]
		[JsonPropertyName("backchannellogoutsessionrequired")]
		public Boolean? BackChannelLogoutSessionRequired {get;set;}

		[DataMember(Name="allowedscopes")]
		[JsonProperty("allowedscopes")]
		[JsonPropertyName("allowedscopes")]
		public String AllowedScopes {get;set;}

		[DataMember(Name="alwaysincludeuserclaimsinidtoken")]
		[JsonProperty("alwaysincludeuserclaimsinidtoken")]
		[JsonPropertyName("alwaysincludeuserclaimsinidtoken")]
		public Boolean? AlwaysIncludeUserClaimsInIdToken {get;set;}

		[DataMember(Name="identitytokenlifetime")]
		[JsonProperty("identitytokenlifetime")]
		[JsonPropertyName("identitytokenlifetime")]
		public Int32? IdentityTokenLifetime {get;set;}

		[DataMember(Name="accesstokenlifetime")]
		[JsonProperty("accesstokenlifetime")]
		[JsonPropertyName("accesstokenlifetime")]
		public Int32? AccessTokenLifetime {get;set;}

		[DataMember(Name="authorizationcodelifetime")]
		[JsonProperty("authorizationcodelifetime")]
		[JsonPropertyName("authorizationcodelifetime")]
		public Int32? AuthorizationCodeLifetime {get;set;}

		[DataMember(Name="absoluterefreshtokenlifetime")]
		[JsonProperty("absoluterefreshtokenlifetime")]
		[JsonPropertyName("absoluterefreshtokenlifetime")]
		public Int32? AbsoluteRefreshTokenLifetime {get;set;}

		[DataMember(Name="slidingrefreshtokenlifetime")]
		[JsonProperty("slidingrefreshtokenlifetime")]
		[JsonPropertyName("slidingrefreshtokenlifetime")]
		public Int32? SlidingRefreshTokenLifetime {get;set;}

		[DataMember(Name="consentlifetime")]
		[JsonProperty("consentlifetime")]
		[JsonPropertyName("consentlifetime")]
		public Int32? ConsentLifetime {get;set;}

		[DataMember(Name="refreshtokenusage")]
		[JsonProperty("refreshtokenusage")]
		[JsonPropertyName("refreshtokenusage")]
		public RefreshTokenUsageTypes? RefreshTokenUsage {get;set;}

		[DataMember(Name="updateaccesstokenclaimsonrefresh")]
		[JsonProperty("updateaccesstokenclaimsonrefresh")]
		[JsonPropertyName("updateaccesstokenclaimsonrefresh")]
		public Boolean? UpdateAccessTokenClaimsOnRefresh {get;set;}

		[DataMember(Name="refreshtokenexpiration")]
		[JsonProperty("refreshtokenexpiration")]
		[JsonPropertyName("refreshtokenexpiration")]
		public RefreshTokenExpirationTypes? RefreshTokenExpiration {get;set;}

		[DataMember(Name="accesstokentype")]
		[JsonProperty("accesstokentype")]
		[JsonPropertyName("accesstokentype")]
		public AccessTokenTypes? AccessTokenType {get;set;}

		[DataMember(Name="properties")]
		[JsonProperty("properties")]
		[JsonPropertyName("properties")]
		public String Properties {get;set;}

		[InverseProperty("Client")]
		[JsonProperty("openidconnectsecrets")]
		[JsonPropertyName("openidconnectsecrets")]
		public ICollection<OpenIdConnectSecret> OpenIdConnectSecrets {get;set;}

		[InverseProperty("Client")]
		[JsonProperty("openidconnectauthorizations")]
		[JsonPropertyName("openidconnectauthorizations")]
		public ICollection<OpenIdConnectAuthorization> OpenIdConnectAuthorizations {get;set;}

		[InverseProperty("Client")]
		[JsonProperty("openidconnecttokens")]
		[JsonPropertyName("openidconnecttokens")]
		public ICollection<OpenIdConnectToken> OpenIdConnectTokens {get;set;}

		[InverseProperty("OpenIdConnectClient")]
		[JsonProperty("allowedgranttypes")]
		[JsonPropertyName("allowedgranttypes")]
		public ICollection<AllowedGrantType> AllowedGrantTypes {get;set;}

		[InverseProperty("OpenIdConnectClient")]
		[JsonProperty("allowedidentitytokensigningalgorithm")]
		[JsonPropertyName("allowedidentitytokensigningalgorithm")]
		public ICollection<AllowedIdentityTokenSigningAlgorithm> AllowedIdentityTokenSigningAlgorithm {get;set;}

	}
}
