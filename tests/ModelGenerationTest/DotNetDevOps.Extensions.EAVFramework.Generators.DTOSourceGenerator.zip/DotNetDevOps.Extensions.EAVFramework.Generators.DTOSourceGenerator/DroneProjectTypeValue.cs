﻿using System;
namespace Kjeldager.Models
{
	public enum DroneProjectTypeValue
	{
		Map = 10,
		Video = 20
	}
}
