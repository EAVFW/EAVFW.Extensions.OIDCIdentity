﻿using EAVFramework;
using System;
using EAVFramework.Shared;
using System.Runtime.Serialization;
using Newtonsoft.Json;
using System.Text.Json.Serialization;
using System.ComponentModel.DataAnnotations.Schema;
using System.Collections.Generic;
using Kjeldager.Models;
namespace Kjeldager.Models
{
	[Serializable()]
	[Entity(LogicalName="powermeter",SchemaName="PowerMeter",CollectionSchemaName="PowerMeters",IsBaseClass=false)]
	[EntityDTO(LogicalName="powermeter",Schema="Kjeldager")]
	public partial class PowerMeter : DynamicEntity
	{
		public PowerMeter()
		{
		}

		[DataMember(Name="name")]
		[JsonProperty("name")]
		[JsonPropertyName("name")]
		[PrimaryField()]
		public String Name {get;set;}

		[DataMember(Name="id")]
		[JsonProperty("id")]
		[JsonPropertyName("id")]
		public Guid Id {get;set;}

		[InverseProperty("PowerMeter")]
		[JsonProperty("powerconsumptionentries")]
		[JsonPropertyName("powerconsumptionentries")]
		public ICollection<PowerConsumptionEntry> PowerConsumptionEntries {get;set;}

	}
}
