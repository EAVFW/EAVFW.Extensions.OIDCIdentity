﻿using System;
namespace Kjeldager.Models
{
	public enum OpenIdConnectClientTypes
	{
		Confidential = 0,
		Public = 1
	}
}
