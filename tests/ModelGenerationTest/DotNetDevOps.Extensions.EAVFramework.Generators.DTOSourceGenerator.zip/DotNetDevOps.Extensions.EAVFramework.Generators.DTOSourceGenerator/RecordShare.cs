﻿using EAVFW.Extensions.SecurityModel;
using Kjeldager.Models;
using EAVFW.Extensions.DynamicManifest;
using System;
using EAVFramework.Shared;
using System.Runtime.Serialization;
using Newtonsoft.Json;
using System.Text.Json.Serialization;
using System.ComponentModel.DataAnnotations.Schema;
namespace Kjeldager.Models
{
	[Serializable()]
	[Entity(LogicalName="recordshare",SchemaName="RecordShare",CollectionSchemaName="RecordShares",IsBaseClass=false)]
	[EntityDTO(LogicalName="recordshare",Schema="Kjeldager")]
	public partial class RecordShare : BaseOwnerEntity<Identity>, ITRecordShare, IAuditFields
	{
		public RecordShare()
		{
		}

		[DataMember(Name="identity")]
		[JsonProperty("identity")]
		[JsonPropertyName("identity")]
		[PrimaryField()]
		public String Identity {get;set;}

		[DataMember(Name="entityname")]
		[JsonProperty("entityname")]
		[JsonPropertyName("entityname")]
		public String EntityName {get;set;}

		[DataMember(Name="recordid")]
		[JsonProperty("recordid")]
		[JsonPropertyName("recordid")]
		public Guid? RecordId {get;set;}

		[DataMember(Name="permissionid")]
		[JsonProperty("permissionid")]
		[JsonPropertyName("permissionid")]
		public Guid? PermissionId {get;set;}

		[ForeignKey("PermissionId")]
		[JsonProperty("permission")]
		[JsonPropertyName("permission")]
		[DataMember(Name="permission")]
		public Permission Permission {get;set;}

	}
}
