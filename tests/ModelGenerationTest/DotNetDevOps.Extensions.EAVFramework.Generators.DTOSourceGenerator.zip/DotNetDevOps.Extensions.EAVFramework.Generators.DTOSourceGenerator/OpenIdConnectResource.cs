﻿using EAVFW.Extensions.SecurityModel;
using Kjeldager.Models;
using EAVFW.Extensions.DynamicManifest;
using System;
using EAVFramework.Shared;
using System.Runtime.Serialization;
using Newtonsoft.Json;
using System.Text.Json.Serialization;
using System.ComponentModel.DataAnnotations.Schema;
using System.Collections.Generic;
using EAVFW.Extensions.OIDCIdentity;

namespace Kjeldager.Models
{
	[Serializable()]
	[Entity(LogicalName="openidconnectresource",SchemaName="OpenIdConnectResource",CollectionSchemaName="OpenIdConnectResources",IsBaseClass=true)]
	[EntityDTO(LogicalName="openidconnectresource",Schema="Kjeldager")]
	public partial class OpenIdConnectResource : BaseOwnerEntity<Identity>, IAuditFields, IOpenIdConnectResource<OpenIdConnectScopeResource, OpenIdConnectResource, OpenIdConnectIdentityResource>
	{
		public OpenIdConnectResource()
		{
		}

		[DataMember(Name="name")]
		[JsonProperty("name")]
		[JsonPropertyName("name")]
		public String Name {get;set;}

		[DataMember(Name="displayname")]
		[JsonProperty("displayname")]
		[JsonPropertyName("displayname")]
		[PrimaryField()]
		public String DisplayName {get;set;}

		[DataMember(Name="description")]
		[JsonProperty("description")]
		[JsonPropertyName("description")]
		public String Description {get;set;}

		[DataMember(Name="showindiscoverydocument")]
		[JsonProperty("showindiscoverydocument")]
		[JsonPropertyName("showindiscoverydocument")]
		public Boolean? ShowInDiscoveryDocument {get;set;}

		[DataMember(Name="properties")]
		[JsonProperty("properties")]
		[JsonPropertyName("properties")]
		public String Properties {get;set;}

		[DataMember(Name="userclaims")]
		[JsonProperty("userclaims")]
		[JsonPropertyName("userclaims")]
		public String UserClaims {get;set;}

		[InverseProperty("Resource")]
		[JsonProperty("openidconnectscoperesources")]
		[JsonPropertyName("openidconnectscoperesources")]
		public ICollection<OpenIdConnectScopeResource> OpenIdConnectScopeResources {get;set;}

	}
}
