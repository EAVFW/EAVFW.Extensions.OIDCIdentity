﻿using Kjeldager.Models;
using System;
using EAVFramework.Shared;
using System.Runtime.Serialization;
using Newtonsoft.Json;
using System.Text.Json.Serialization;
using System.ComponentModel.DataAnnotations.Schema;
using System.Collections.Generic;
using EAVFW.Extensions.OIDCIdentity;

namespace Kjeldager.Models
{
	[Serializable()]
	[Entity(LogicalName="openidconnectidentityresource",SchemaName="OpenIdConnectIdentityResource",CollectionSchemaName="OpenIdConnectIdentityResources",IsBaseClass=false)]
	[EntityDTO(LogicalName="openidconnectidentityresource",Schema="Kjeldager")]
	public partial class OpenIdConnectIdentityResource : OpenIdConnectResource, IOpenIdConnectIdentityResource
	{
		public OpenIdConnectIdentityResource()
		{
		}

		[DataMember(Name="required")]
		[JsonProperty("required")]
		[JsonPropertyName("required")]
		public Boolean? Required {get;set;}

		[DataMember(Name="emphasize")]
		[JsonProperty("emphasize")]
		[JsonPropertyName("emphasize")]
		public Boolean? Emphasize {get;set;}

		[InverseProperty("Scope")]
		[JsonProperty("openidconnectauthorizationscopes")]
		[JsonPropertyName("openidconnectauthorizationscopes")]
		public ICollection<OpenIdConnectAuthorizationScope> OpenIdConnectAuthorizationScopes {get;set;}

		[InverseProperty("Scope")]
		[JsonProperty("openidconnectscoperesources")]
		[JsonPropertyName("openidconnectscoperesources")]
		public ICollection<OpenIdConnectScopeResource> OpenIdConnectScopeResources {get;set;}

	}
}
