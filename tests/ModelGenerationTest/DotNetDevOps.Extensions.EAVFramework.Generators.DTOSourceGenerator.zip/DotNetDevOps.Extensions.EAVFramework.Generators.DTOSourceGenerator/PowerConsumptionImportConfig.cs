﻿using EAVFW.Extensions.SecurityModel;
using Kjeldager.Models;
using EAVFW.Extensions.DynamicManifest;
using System;
using EAVFramework.Shared;
using System.Runtime.Serialization;
using Newtonsoft.Json;
using System.Text.Json.Serialization;
using System.ComponentModel.DataAnnotations.Schema;
namespace Kjeldager.Models
{
	[Serializable()]
	[Entity(LogicalName="powerconsumptionimportconfig",SchemaName="PowerConsumptionImportConfig",CollectionSchemaName="PowerConsumptionImportConfigs",IsBaseClass=false)]
	[EntityDTO(LogicalName="powerconsumptionimportconfig",Schema="Kjeldager")]
	public partial class PowerConsumptionImportConfig : BaseOwnerEntity<Identity>, IAuditFields
	{
		public PowerConsumptionImportConfig()
		{
		}

		[DataMember(Name="name")]
		[JsonProperty("name")]
		[JsonPropertyName("name")]
		[PrimaryField()]
		public String Name {get;set;}

		[DataMember(Name="configurationid")]
		[JsonProperty("configurationid")]
		[JsonPropertyName("configurationid")]
		public Guid? ConfigurationId {get;set;}

		[ForeignKey("ConfigurationId")]
		[JsonProperty("configuration")]
		[JsonPropertyName("configuration")]
		[DataMember(Name="configuration")]
		public Document Configuration {get;set;}

	}
}
