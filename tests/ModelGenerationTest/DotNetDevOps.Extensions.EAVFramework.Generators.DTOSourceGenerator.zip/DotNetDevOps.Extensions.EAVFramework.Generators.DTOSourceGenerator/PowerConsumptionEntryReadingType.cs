﻿using System;
namespace Kjeldager.Models
{
	public enum PowerConsumptionEntryReadingType
	{
		Measured = 0,
		NotSpecified = 99
	}
}
