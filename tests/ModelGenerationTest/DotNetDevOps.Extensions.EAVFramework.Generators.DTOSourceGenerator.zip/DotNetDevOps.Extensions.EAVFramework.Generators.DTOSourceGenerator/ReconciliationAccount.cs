﻿using EAVFW.Extensions.SecurityModel;
using Kjeldager.Models;
using EAVFW.Extensions.DynamicManifest;
using System;
using EAVFramework.Shared;
using System.Runtime.Serialization;
using Newtonsoft.Json;
using System.Text.Json.Serialization;
using System.ComponentModel.DataAnnotations.Schema;
using System.Collections.Generic;
namespace Kjeldager.Models
{
	[Serializable()]
	[Entity(LogicalName="reconciliationaccount",SchemaName="ReconciliationAccount",CollectionSchemaName="ReconciliationAccounts",IsBaseClass=false)]
	[EntityDTO(LogicalName="reconciliationaccount",Schema="Kjeldager")]
	public partial class ReconciliationAccount : BaseOwnerEntity<Identity>, IAuditFields
	{
		public ReconciliationAccount()
		{
		}

		[DataMember(Name="name")]
		[JsonProperty("name")]
		[JsonPropertyName("name")]
		[PrimaryField()]
		public String Name {get;set;}

		[DataMember(Name="registrationnumber")]
		[JsonProperty("registrationnumber")]
		[JsonPropertyName("registrationnumber")]
		public String RegistrationNumber {get;set;}

		[DataMember(Name="accountnumber")]
		[JsonProperty("accountnumber")]
		[JsonPropertyName("accountnumber")]
		public String AccountNumber {get;set;}

		[DataMember(Name="amount")]
		[JsonProperty("amount")]
		[JsonPropertyName("amount")]
		public Decimal? Amount {get;set;}

		[DataMember(Name="amountcurrencyid")]
		[JsonProperty("amountcurrencyid")]
		[JsonPropertyName("amountcurrencyid")]
		public Guid? AmountCurrencyId {get;set;}

		[ForeignKey("AmountCurrencyId")]
		[JsonProperty("amountcurrency")]
		[JsonPropertyName("amountcurrency")]
		[DataMember(Name="amountcurrency")]
		public Currency AmountCurrency {get;set;}

		[InverseProperty("ReconciliationAccount")]
		[JsonProperty("reconciliationentries")]
		[JsonPropertyName("reconciliationentries")]
		public ICollection<ReconciliationEntry> ReconciliationEntries {get;set;}

	}
}
