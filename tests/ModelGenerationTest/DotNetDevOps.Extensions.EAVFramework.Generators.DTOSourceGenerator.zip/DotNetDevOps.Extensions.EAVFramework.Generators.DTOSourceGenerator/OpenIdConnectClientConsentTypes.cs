﻿using System;
namespace Kjeldager.Models
{
	public enum OpenIdConnectClientConsentTypes
	{
		Explicit = 0,
		External = 1,
		Implicit = 2,
		Systematic = 3
	}
}
