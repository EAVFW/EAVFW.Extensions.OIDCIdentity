﻿using Kjeldager.Models;
using System;
using EAVFramework.Shared;
using System.Runtime.Serialization;
using Newtonsoft.Json;
using System.Text.Json.Serialization;
namespace Kjeldager.Models
{
	[Serializable()]
	[Entity(LogicalName="systemuser",SchemaName="SystemUser",CollectionSchemaName="SystemUsers",IsBaseClass=false)]
	[EntityDTO(LogicalName="systemuser",Schema="Kjeldager")]
	public partial class SystemUser : Identity
	{
		public SystemUser()
		{
		}

		[DataMember(Name="email")]
		[JsonProperty("email")]
		[JsonPropertyName("email")]
		public String Email {get;set;}

	}
}
