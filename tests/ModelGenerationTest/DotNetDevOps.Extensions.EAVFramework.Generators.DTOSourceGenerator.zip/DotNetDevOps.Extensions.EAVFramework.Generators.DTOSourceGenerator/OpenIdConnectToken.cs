﻿using EAVFW.Extensions.SecurityModel;
using Kjeldager.Models;
using EAVFW.Extensions.DynamicManifest;
using System;
using EAVFramework.Shared;
using System.Runtime.Serialization;
using Newtonsoft.Json;
using System.Text.Json.Serialization;
using System.ComponentModel.DataAnnotations.Schema;
using EAVFW.Extensions.OIDCIdentity;

namespace Kjeldager.Models
{
	[Serializable()]
	[Entity(LogicalName="openidconnecttoken",SchemaName="OpenIdConnectToken",CollectionSchemaName="OpenIdConnectTokens",IsBaseClass=false)]
	[EntityDTO(LogicalName="openidconnecttoken",Schema="Kjeldager")]
	public partial class OpenIdConnectToken : BaseOwnerEntity<Identity>, IAuditFields, IOpenIdConnectToken<OpenIdConnectClient, OpenIdConnectAuthorization, OpenIdConnectTokenStatus, OpenIdConnectTokenType, OpenIdConnectAuthorizationStatus, OpenIdConnectAuthorizationType,
		AllowedGrantType, OpenIdConnectAuthorizationScope, OpenIdConnectToken,OpenIdConnectClientTypes, OpenIdConnectClientConsentTypes, AllowedGrantTypeValue, OpenIdConnectIdentityResource>
	{
		public OpenIdConnectToken()
		{
		}

		[DataMember(Name="name")]
		[JsonProperty("name")]
		[JsonPropertyName("name")]
		[PrimaryField()]
		public String Name {get;set;}

		[DataMember(Name="clientid")]
		[JsonProperty("clientid")]
		[JsonPropertyName("clientid")]
		public Guid? ClientId {get;set;}

		[ForeignKey("ClientId")]
		[JsonProperty("client")]
		[JsonPropertyName("client")]
		[DataMember(Name="client")]
		public OpenIdConnectClient Client {get;set;}

		[DataMember(Name="authorizationid")]
		[JsonProperty("authorizationid")]
		[JsonPropertyName("authorizationid")]
		public Guid? AuthorizationId {get;set;}

		[ForeignKey("AuthorizationId")]
		[JsonProperty("authorization")]
		[JsonPropertyName("authorization")]
		[DataMember(Name="authorization")]
		public OpenIdConnectAuthorization Authorization {get;set;}

		[DataMember(Name="subjectid")]
		[JsonProperty("subjectid")]
		[JsonPropertyName("subjectid")]
		public Guid? SubjectId {get;set;}

		[ForeignKey("SubjectId")]
		[JsonProperty("subject")]
		[JsonPropertyName("subject")]
		[DataMember(Name="subject")]
		public Identity Subject {get;set;}

		[DataMember(Name="status")]
		[JsonProperty("status")]
		[JsonPropertyName("status")]
		public OpenIdConnectTokenStatus? Status {get;set;}

		[DataMember(Name="type")]
		[JsonProperty("type")]
		[JsonPropertyName("type")]
		public OpenIdConnectTokenType? Type {get;set;}

		[DataMember(Name="expirationdate")]
		[JsonProperty("expirationdate")]
		[JsonPropertyName("expirationdate")]
		public DateTime? ExpirationDate {get;set;}

		[DataMember(Name="redemptiondate")]
		[JsonProperty("redemptiondate")]
		[JsonPropertyName("redemptiondate")]
		public DateTime? RedemptionDate {get;set;}

		[DataMember(Name="payload")]
		[JsonProperty("payload")]
		[JsonPropertyName("payload")]
		public String Payload {get;set;}

		[DataMember(Name="referenceid")]
		[JsonProperty("referenceid")]
		[JsonPropertyName("referenceid")]
		public Guid? ReferenceId {get;set;}

		[DataMember(Name="properties")]
		[JsonProperty("properties")]
		[JsonPropertyName("properties")]
		public String Properties {get;set;}

	}
}
