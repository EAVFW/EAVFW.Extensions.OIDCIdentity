﻿using EAVFW.Extensions.SecurityModel;
using Kjeldager.Models;
using EAVFW.Extensions.DynamicManifest;
using System;
using EAVFramework.Shared;
using System.Runtime.Serialization;
using Newtonsoft.Json;
using System.Text.Json.Serialization;
using System.ComponentModel.DataAnnotations.Schema;
namespace Kjeldager.Models
{
	[Serializable()]
	[Entity(LogicalName="reconciliationentry",SchemaName="ReconciliationEntry",CollectionSchemaName="ReconciliationEntries",IsBaseClass=false)]
	[EntityDTO(LogicalName="reconciliationentry",Schema="Kjeldager")]
	public partial class ReconciliationEntry : BaseOwnerEntity<Identity>, IAuditFields
	{
		public ReconciliationEntry()
		{
		}

		[DataMember(Name="entrytext")]
		[JsonProperty("entrytext")]
		[JsonPropertyName("entrytext")]
		[PrimaryField()]
		public String EntryText {get;set;}

		[DataMember(Name="entrytype")]
		[JsonProperty("entrytype")]
		[JsonPropertyName("entrytype")]
		public ReconciliationEntryType? EntryType {get;set;}

		[DataMember(Name="cardtype")]
		[JsonProperty("cardtype")]
		[JsonPropertyName("cardtype")]
		public String CardType {get;set;}

		[DataMember(Name="creditoridentification")]
		[JsonProperty("creditoridentification")]
		[JsonPropertyName("creditoridentification")]
		public String CreditorIdentification {get;set;}

		[DataMember(Name="bankreference")]
		[JsonProperty("bankreference")]
		[JsonPropertyName("bankreference")]
		public String BankReference {get;set;}

		[DataMember(Name="bookdate")]
		[JsonProperty("bookdate")]
		[JsonPropertyName("bookdate")]
		public DateTime? BookDate {get;set;}

		[DataMember(Name="valuedate")]
		[JsonProperty("valuedate")]
		[JsonPropertyName("valuedate")]
		public DateTime? ValueDate {get;set;}

		[DataMember(Name="originalpaymentdate")]
		[JsonProperty("originalpaymentdate")]
		[JsonPropertyName("originalpaymentdate")]
		public DateTime? OriginalPaymentDate {get;set;}

		[DataMember(Name="amount")]
		[JsonProperty("amount")]
		[JsonPropertyName("amount")]
		public Decimal? Amount {get;set;}

		[DataMember(Name="amountcurrencyid")]
		[JsonProperty("amountcurrencyid")]
		[JsonPropertyName("amountcurrencyid")]
		public Guid? AmountCurrencyId {get;set;}

		[ForeignKey("AmountCurrencyId")]
		[JsonProperty("amountcurrency")]
		[JsonPropertyName("amountcurrency")]
		[DataMember(Name="amountcurrency")]
		public Currency AmountCurrency {get;set;}

		[DataMember(Name="originalamount")]
		[JsonProperty("originalamount")]
		[JsonPropertyName("originalamount")]
		public Decimal? OriginalAmount {get;set;}

		[DataMember(Name="originalamountcurrencyid")]
		[JsonProperty("originalamountcurrencyid")]
		[JsonPropertyName("originalamountcurrencyid")]
		public Guid? OriginalAmountCurrencyId {get;set;}

		[ForeignKey("OriginalAmountCurrencyId")]
		[JsonProperty("originalamountcurrency")]
		[JsonPropertyName("originalamountcurrency")]
		[DataMember(Name="originalamountcurrency")]
		public Currency OriginalAmountCurrency {get;set;}

		[DataMember(Name="exchangerate")]
		[JsonProperty("exchangerate")]
		[JsonPropertyName("exchangerate")]
		public Decimal? ExchangeRate {get;set;}

		[DataMember(Name="feeamount")]
		[JsonProperty("feeamount")]
		[JsonPropertyName("feeamount")]
		public Decimal? FeeAmount {get;set;}

		[DataMember(Name="feecurrencyid")]
		[JsonProperty("feecurrencyid")]
		[JsonPropertyName("feecurrencyid")]
		public Guid? FeeCurrencyId {get;set;}

		[ForeignKey("FeeCurrencyId")]
		[JsonProperty("feecurrency")]
		[JsonPropertyName("feecurrency")]
		[DataMember(Name="feecurrency")]
		public Currency FeeCurrency {get;set;}

		[DataMember(Name="payeridentification")]
		[JsonProperty("payeridentification")]
		[JsonPropertyName("payeridentification")]
		public String PayerIdentification {get;set;}

		[DataMember(Name="payernameandaddress")]
		[JsonProperty("payernameandaddress")]
		[JsonPropertyName("payernameandaddress")]
		public String PayerNameandAddress {get;set;}

		[DataMember(Name="senderidentification")]
		[JsonProperty("senderidentification")]
		[JsonPropertyName("senderidentification")]
		public String SenderIdentification {get;set;}

		[DataMember(Name="messagefromsender")]
		[JsonProperty("messagefromsender")]
		[JsonPropertyName("messagefromsender")]
		public String MessageFromSender {get;set;}

		[DataMember(Name="reconciliationsourceid")]
		[JsonProperty("reconciliationsourceid")]
		[JsonPropertyName("reconciliationsourceid")]
		public Guid? ReconciliationSourceId {get;set;}

		[ForeignKey("ReconciliationSourceId")]
		[JsonProperty("reconciliationsource")]
		[JsonPropertyName("reconciliationsource")]
		[DataMember(Name="reconciliationsource")]
		public ReconciliationSource ReconciliationSource {get;set;}

		[DataMember(Name="reconciliationaccountid")]
		[JsonProperty("reconciliationaccountid")]
		[JsonPropertyName("reconciliationaccountid")]
		public Guid? ReconciliationAccountId {get;set;}

		[ForeignKey("ReconciliationAccountId")]
		[JsonProperty("reconciliationaccount")]
		[JsonPropertyName("reconciliationaccount")]
		[DataMember(Name="reconciliationaccount")]
		public ReconciliationAccount ReconciliationAccount {get;set;}

		[DataMember(Name="balance")]
		[JsonProperty("balance")]
		[JsonPropertyName("balance")]
		public Decimal? Balance {get;set;}

		[DataMember(Name="balancecurrencyid")]
		[JsonProperty("balancecurrencyid")]
		[JsonPropertyName("balancecurrencyid")]
		public Guid? BalanceCurrencyId {get;set;}

		[ForeignKey("BalanceCurrencyId")]
		[JsonProperty("balancecurrency")]
		[JsonPropertyName("balancecurrency")]
		[DataMember(Name="balancecurrency")]
		public Currency BalanceCurrency {get;set;}

		[DataMember(Name="status")]
		[JsonProperty("status")]
		[JsonPropertyName("status")]
		public ReconciliationEntryStatus? Status {get;set;}

	}
}
