﻿using EAVFramework;
using System;
using EAVFramework.Shared;
using System.Runtime.Serialization;
using Newtonsoft.Json;
using System.Text.Json.Serialization;
using System.ComponentModel.DataAnnotations.Schema;
using Kjeldager.Models;
using EAVFW.Extensions.OIDCIdentity;

namespace Kjeldager.Models
{
	[Serializable()]
	[Entity(LogicalName="openidconnectscoperesource",SchemaName="OpenIdConnectScopeResource",CollectionSchemaName="OpenIdConnectScopeResources",IsBaseClass=false)]
	[EntityDTO(LogicalName="openidconnectscoperesource",Schema="Kjeldager")]
	public partial class OpenIdConnectScopeResource : DynamicEntity, IOpenIdConnectScopeResource<OpenIdConnectResource, OpenIdConnectScopeResource, OpenIdConnectIdentityResource>
	{
		public OpenIdConnectScopeResource()
		{
		}

		[DataMember(Name="resourceid")]
		[JsonProperty("resourceid")]
		[JsonPropertyName("resourceid")]
		public Guid? ResourceId {get;set;}

		[ForeignKey("ResourceId")]
		[JsonProperty("resource")]
		[JsonPropertyName("resource")]
		[DataMember(Name="resource")]
		public OpenIdConnectResource Resource {get;set;}

		[DataMember(Name="scopeid")]
		[JsonProperty("scopeid")]
		[JsonPropertyName("scopeid")]
		public Guid? ScopeId {get;set;}

		[ForeignKey("ScopeId")]
		[JsonProperty("scope")]
		[JsonPropertyName("scope")]
		[DataMember(Name="scope")]
		public OpenIdConnectIdentityResource Scope {get;set;}

		[DataMember(Name="id")]
		[JsonProperty("id")]
		[JsonPropertyName("id")]
		public Guid Id {get;set;}

	}
}
