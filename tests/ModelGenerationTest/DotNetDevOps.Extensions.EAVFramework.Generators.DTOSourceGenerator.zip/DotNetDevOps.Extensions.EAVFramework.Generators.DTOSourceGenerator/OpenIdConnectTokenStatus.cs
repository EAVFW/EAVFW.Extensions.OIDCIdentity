﻿using System;
namespace Kjeldager.Models
{
	 
	public enum OpenIdConnectTokenStatus
	{
		Inactive = 0,
		Valid = 1,
		Redeemed = 2,
		Rejected = 3,
		Revoked = 4
	}
}
