﻿using System;
namespace Kjeldager.Models
{
	public enum ReconciliationEntryStatus
	{
		Processing = 0,
		Unmatched = 10,
		Matched = 20,
		Failed = 50,
		Inactive = 99
	}
}
