﻿using EAVFW.Extensions.SecurityModel;
using Kjeldager.Models;
using EAVFW.Extensions.Configuration;
using EAVFW.Extensions.DynamicManifest;
using System;
using EAVFramework.Shared;
using System.Runtime.Serialization;
using Newtonsoft.Json;
using System.Text.Json.Serialization;
using System.ComponentModel.DataAnnotations.Schema;
using System.Collections.Generic;
namespace Kjeldager.Models
{
	[Serializable()]
	[Entity(LogicalName="server",SchemaName="Server",CollectionSchemaName="Servers",IsBaseClass=false)]
	[EntityDTO(LogicalName="server",Schema="Kjeldager")]
	public partial class Server : BaseOwnerEntity<Identity>, IServerEntity, IAuditFields
	{
		public Server()
		{
		}

		[DataMember(Name="name")]
		[JsonProperty("name")]
		[JsonPropertyName("name")]
		[PrimaryField()]
		public String Name {get;set;}

		[DataMember(Name="heartbeat")]
		[JsonProperty("heartbeat")]
		[JsonPropertyName("heartbeat")]
		public DateTime? Heartbeat {get;set;}

		[InverseProperty("Server")]
		[JsonProperty("environmentvariables")]
		[JsonPropertyName("environmentvariables")]
		public ICollection<EnvironmentVariable> EnvironmentVariables {get;set;}

	}
}
