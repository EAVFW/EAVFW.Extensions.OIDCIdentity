﻿using EAVFW.Extensions.SecurityModel;
using Kjeldager.Models;
using EAVFW.Extensions.DynamicManifest;
using System;
using EAVFramework.Shared;
using System.Runtime.Serialization;
using Newtonsoft.Json;
using System.Text.Json.Serialization;
using System.ComponentModel.DataAnnotations.Schema;
using System.Collections.Generic;
namespace Kjeldager.Models
{
	[Serializable()]
	[Entity(LogicalName="reconciliationsource",SchemaName="ReconciliationSource",CollectionSchemaName="ReconciliationSources",IsBaseClass=false)]
	[EntityDTO(LogicalName="reconciliationsource",Schema="Kjeldager")]
	public partial class ReconciliationSource : BaseOwnerEntity<Identity>, IAuditFields
	{
		public ReconciliationSource()
		{
		}

		[DataMember(Name="name")]
		[JsonProperty("name")]
		[JsonPropertyName("name")]
		[PrimaryField()]
		public String Name {get;set;}

		[DataMember(Name="dataid")]
		[JsonProperty("dataid")]
		[JsonPropertyName("dataid")]
		public Guid? DataId {get;set;}

		[ForeignKey("DataId")]
		[JsonProperty("data")]
		[JsonPropertyName("data")]
		[DataMember(Name="data")]
		public Document Data {get;set;}

		[DataMember(Name="parserconfigurationid")]
		[JsonProperty("parserconfigurationid")]
		[JsonPropertyName("parserconfigurationid")]
		public Guid? ParserConfigurationId {get;set;}

		[ForeignKey("ParserConfigurationId")]
		[JsonProperty("parserconfiguration")]
		[JsonPropertyName("parserconfiguration")]
		[DataMember(Name="parserconfiguration")]
		public ReconciliationParserConfig ParserConfiguration {get;set;}

		[DataMember(Name="status")]
		[JsonProperty("status")]
		[JsonPropertyName("status")]
		public ReconciliationSourceStatus? Status {get;set;}

		[InverseProperty("ReconciliationSource")]
		[JsonProperty("reconciliationentries")]
		[JsonPropertyName("reconciliationentries")]
		public ICollection<ReconciliationEntry> ReconciliationEntries {get;set;}

	}
}
