﻿using System;
namespace Kjeldager.Models
{
	public enum AllowedGrantTypeValue
	{
		AuthorizationCode = 1,
		Implicit = 2,
		ResourceOwner = 3,
		ClientCredentials = 4,
		Hybrid = 5,
		DeviceFlow = 6,
		RefreshToken = 7
	}
}
