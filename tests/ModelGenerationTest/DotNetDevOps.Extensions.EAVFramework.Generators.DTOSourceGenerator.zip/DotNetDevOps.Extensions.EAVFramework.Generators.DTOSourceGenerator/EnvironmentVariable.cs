﻿using EAVFW.Extensions.SecurityModel;
using Kjeldager.Models;
using EAVFW.Extensions.Configuration;
using EAVFW.Extensions.DynamicManifest;
using System;
using EAVFramework.Shared;
using System.Runtime.Serialization;
using Newtonsoft.Json;
using System.Text.Json.Serialization;
using System.ComponentModel.DataAnnotations.Schema;
namespace Kjeldager.Models
{
	[Serializable()]
	[Entity(LogicalName="environmentvariable",SchemaName="EnvironmentVariable",CollectionSchemaName="EnvironmentVariables",IsBaseClass=false)]
	[EntityDTO(LogicalName="environmentvariable",Schema="Kjeldager")]
	public partial class EnvironmentVariable : BaseOwnerEntity<Identity>, IEnvironmentVariable, IAuditFields
	{
		public EnvironmentVariable()
		{
		}

		[DataMember(Name="name")]
		[JsonProperty("name")]
		[JsonPropertyName("name")]
		[PrimaryField()]
		public String Name {get;set;}

		[DataMember(Name="serverid")]
		[JsonProperty("serverid")]
		[JsonPropertyName("serverid")]
		public Guid? ServerId {get;set;}

		[ForeignKey("ServerId")]
		[JsonProperty("server")]
		[JsonPropertyName("server")]
		[DataMember(Name="server")]
		public Server Server {get;set;}

		[DataMember(Name="applicationname")]
		[JsonProperty("applicationname")]
		[JsonPropertyName("applicationname")]
		public String ApplicationName {get;set;}

		[DataMember(Name="value")]
		[JsonProperty("value")]
		[JsonPropertyName("value")]
		public String Value {get;set;}

	}
}
