﻿using EAVFW.Extensions.SecurityModel;
using Kjeldager.Models;
using EAVFW.Extensions.DynamicManifest;
using System;
using EAVFramework.Shared;
using System.Runtime.Serialization;
using Newtonsoft.Json;
using System.Text.Json.Serialization;
using System.ComponentModel.DataAnnotations.Schema;
using System.Collections.Generic;
using EAVFW.Extensions.OIDCIdentity;

namespace Kjeldager.Models
{
	[Serializable()]
	[Entity(LogicalName="openidconnectauthorization",SchemaName="OpenIdConnectAuthorization",CollectionSchemaName="OpenIdConnectAuthorizations",IsBaseClass=false)]
	[EntityDTO(LogicalName="openidconnectauthorization",Schema="Kjeldager")]
	public partial class OpenIdConnectAuthorization : BaseOwnerEntity<Identity>, IAuditFields, IOpenIdConnectAuthorization<OpenIdConnectClient, AllowedGrantType, OpenIdConnectAuthorizationStatus, OpenIdConnectAuthorizationType, OpenIdConnectAuthorizationScope, OpenIdConnectAuthorization,
		OpenIdConnectToken, OpenIdConnectTokenStatus, OpenIdConnectTokenType, OpenIdConnectClientTypes, OpenIdConnectClientConsentTypes, AllowedGrantTypeValue, OpenIdConnectIdentityResource>
	{
		public OpenIdConnectAuthorization()
		{
		}

		[DataMember(Name="name")]
		[JsonProperty("name")]
		[JsonPropertyName("name")]
		[PrimaryField()]
		public String Name {get;set;}

		[DataMember(Name="subjectid")]
		[JsonProperty("subjectid")]
		[JsonPropertyName("subjectid")]
		public Guid? SubjectId {get;set;}

		[ForeignKey("SubjectId")]
		[JsonProperty("subject")]
		[JsonPropertyName("subject")]
		[DataMember(Name="subject")]
		public Identity Subject {get;set;}

		[DataMember(Name="status")]
		[JsonProperty("status")]
		[JsonPropertyName("status")]
		public OpenIdConnectAuthorizationStatus? Status {get;set;}

		[DataMember(Name="type")]
		[JsonProperty("type")]
		[JsonPropertyName("type")]
		public OpenIdConnectAuthorizationType? Type {get;set;}

		[DataMember(Name="clientid")]
		[JsonProperty("clientid")]
		[JsonPropertyName("clientid")]
		public Guid? ClientId {get;set;}

		[ForeignKey("ClientId")]
		[JsonProperty("client")]
		[JsonPropertyName("client")]
		[DataMember(Name="client")]
		public OpenIdConnectClient Client {get;set;}

		[DataMember(Name="properties")]
		[JsonProperty("properties")]
		[JsonPropertyName("properties")]
		public String Properties {get;set;}

		[InverseProperty("Authorization")]
		[JsonProperty("openidconnecttokens")]
		[JsonPropertyName("openidconnecttokens")]
		public ICollection<OpenIdConnectToken> OpenIdConnectTokens {get;set;}

		[InverseProperty("Authorization")]
		[JsonProperty("openidconnectauthorizationscopes")]
		[JsonPropertyName("openidconnectauthorizationscopes")]
		public ICollection<OpenIdConnectAuthorizationScope> OpenIdConnectAuthorizationScopes {get;set;}

	}
}
