﻿using System;
namespace Kjeldager.Models
{
	public enum PowerConsumptionEntryUnitTypes
	{
		Kwh = 0
	}
}
