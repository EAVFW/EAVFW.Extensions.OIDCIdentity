﻿using System;
namespace Kjeldager.Models
{
	public enum OpenIdConnectTokenType
	{
		AccessToken = 0,
		IdentityToken = 1
	}
}
