﻿using System;
namespace Kjeldager.Models
{
	public enum ReconciliationSourceStatus
	{
		New = 0,
		Processing = 10,
		Success = 20,
		Failed = 50,
		Inactive = 99
	}
}
