﻿using EAVFramework;
using System;
using EAVFramework.Shared;
using System.Runtime.Serialization;
using Newtonsoft.Json;
using System.Text.Json.Serialization;
using System.ComponentModel.DataAnnotations.Schema;
using Kjeldager.Models;
namespace Kjeldager.Models
{
	[Serializable()]
	[Entity(LogicalName="allowedidentitytokensigningalgorithm",SchemaName="AllowedIdentityTokenSigningAlgorithm",CollectionSchemaName="AllowedIdentityTokenSigningAlgorithm",IsBaseClass=false)]
	[EntityDTO(LogicalName="allowedidentitytokensigningalgorithm",Schema="Kjeldager")]
	public partial class AllowedIdentityTokenSigningAlgorithm : DynamicEntity
	{
		public AllowedIdentityTokenSigningAlgorithm()
		{
		}

		[DataMember(Name="id")]
		[JsonProperty("id")]
		[JsonPropertyName("id")]
		public Guid Id {get;set;}

		[DataMember(Name="openidconnectclientid")]
		[JsonProperty("openidconnectclientid")]
		[JsonPropertyName("openidconnectclientid")]
		public Guid? OpenIdConnectClientId {get;set;}

		[ForeignKey("OpenIdConnectClientId")]
		[JsonProperty("openidconnectclient")]
		[JsonPropertyName("openidconnectclient")]
		[DataMember(Name="openidconnectclient")]
		public OpenIdConnectClient OpenIdConnectClient {get;set;}

		[DataMember(Name="allowedidentitytokensigningalgorithm")]
		[JsonProperty("allowedidentitytokensigningalgorithm")]
		[JsonPropertyName("allowedidentitytokensigningalgorithm")]
		public AllowedIdentityTokenSigningAlgorithmValue? AllowedIdentityTokenSigningAlgorithmValue {get;set;}

	}
}
