﻿using EAVFW.Extensions.SecurityModel;
using Kjeldager.Models;
using EAVFW.Extensions.DynamicManifest;
using System;
using EAVFramework.Shared;
using System.Runtime.Serialization;
using Newtonsoft.Json;
using System.Text.Json.Serialization;
using System.ComponentModel.DataAnnotations.Schema;
namespace Kjeldager.Models
{
	[Serializable()]
	[Entity(LogicalName="securitygroupmember",SchemaName="SecurityGroupMember",CollectionSchemaName="SecurityGroupMembers",IsBaseClass=false)]
	[EntityDTO(LogicalName="securitygroupmember",Schema="Kjeldager")]
	public partial class SecurityGroupMember : BaseOwnerEntity<Identity>, ISecurityGroupMember, IAuditFields
	{
		public SecurityGroupMember()
		{
		}

		[DataMember(Name="identityid")]
		[JsonProperty("identityid")]
		[JsonPropertyName("identityid")]
		public Guid? IdentityId {get;set;}

		[ForeignKey("IdentityId")]
		[JsonProperty("identity")]
		[JsonPropertyName("identity")]
		[DataMember(Name="identity")]
		public Identity Identity {get;set;}

		[DataMember(Name="securitygroupid")]
		[JsonProperty("securitygroupid")]
		[JsonPropertyName("securitygroupid")]
		public Guid? SecurityGroupId {get;set;}

		[ForeignKey("SecurityGroupId")]
		[JsonProperty("securitygroup")]
		[JsonPropertyName("securitygroup")]
		[DataMember(Name="securitygroup")]
		public SecurityGroup SecurityGroup {get;set;}

	}
}
