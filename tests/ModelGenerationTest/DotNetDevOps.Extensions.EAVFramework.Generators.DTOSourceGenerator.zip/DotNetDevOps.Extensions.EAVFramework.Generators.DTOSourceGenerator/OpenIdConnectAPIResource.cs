﻿using Kjeldager.Models;
using System;
using EAVFramework.Shared;
using System.Runtime.Serialization;
using Newtonsoft.Json;
using System.Text.Json.Serialization;
using System.ComponentModel.DataAnnotations.Schema;
using System.Collections.Generic;
namespace Kjeldager.Models
{
	[Serializable()]
	[Entity(LogicalName="openidconnectapiresource",SchemaName="OpenIdConnectAPIResource",CollectionSchemaName="OpenIdConnectAPIResources",IsBaseClass=false)]
	[EntityDTO(LogicalName="openidconnectapiresource",Schema="Kjeldager")]
	public partial class OpenIdConnectAPIResource : OpenIdConnectResource
	{
		public OpenIdConnectAPIResource()
		{
		}

		[DataMember(Name="required")]
		[JsonProperty("required")]
		[JsonPropertyName("required")]
		public Boolean? Required {get;set;}

		[DataMember(Name="emphasize")]
		[JsonProperty("emphasize")]
		[JsonPropertyName("emphasize")]
		public Boolean? Emphasize {get;set;}

		[DataMember(Name="requireresourceindicator")]
		[JsonProperty("requireresourceindicator")]
		[JsonPropertyName("requireresourceindicator")]
		public Boolean? RequireResourceIndicator {get;set;}

		[InverseProperty("Api")]
		[JsonProperty("openidconnectsecrets")]
		[JsonPropertyName("openidconnectsecrets")]
		public ICollection<OpenIdConnectSecret> OpenIdConnectSecrets {get;set;}

	}
}
