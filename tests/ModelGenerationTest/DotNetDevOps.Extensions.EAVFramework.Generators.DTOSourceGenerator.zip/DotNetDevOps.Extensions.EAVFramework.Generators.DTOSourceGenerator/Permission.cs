﻿using EAVFW.Extensions.SecurityModel;
using Kjeldager.Models;
using EAVFW.Extensions.DynamicManifest;
using System;
using EAVFramework.Shared;
using System.Runtime.Serialization;
using Newtonsoft.Json;
using System.Text.Json.Serialization;
using System.ComponentModel.DataAnnotations.Schema;
using System.Collections.Generic;
namespace Kjeldager.Models
{
	[Serializable()]
	[Entity(LogicalName="permission",SchemaName="Permission",CollectionSchemaName="Permissions",IsBaseClass=false)]
	[EntityDTO(LogicalName="permission",Schema="Kjeldager")]
	public partial class Permission : BaseOwnerEntity<Identity>, IPermission, IAuditFields
	{
		public Permission()
		{
		}

		[DataMember(Name="name")]
		[JsonProperty("name")]
		[JsonPropertyName("name")]
		[PrimaryField()]
		public String Name {get;set;}

		[DataMember(Name="description")]
		[JsonProperty("description")]
		[JsonPropertyName("description")]
		public String Description {get;set;}

		[InverseProperty("Permission")]
		[JsonProperty("securityrolepermissions")]
		[JsonPropertyName("securityrolepermissions")]
		public ICollection<SecurityRolePermission> SecurityRolePermissions {get;set;}

		[InverseProperty("Permission")]
		[JsonProperty("recordshares")]
		[JsonPropertyName("recordshares")]
		public ICollection<RecordShare> RecordShares {get;set;}

	}
}
