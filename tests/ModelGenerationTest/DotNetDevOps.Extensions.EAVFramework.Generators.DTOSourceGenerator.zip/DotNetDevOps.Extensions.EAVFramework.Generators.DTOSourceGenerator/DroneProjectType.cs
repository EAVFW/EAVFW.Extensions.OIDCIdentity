﻿using EAVFramework;
using System;
using EAVFramework.Shared;
using System.Runtime.Serialization;
using Newtonsoft.Json;
using System.Text.Json.Serialization;
using System.ComponentModel.DataAnnotations.Schema;
using Kjeldager.Models;
namespace Kjeldager.Models
{
	[Serializable()]
	[Entity(LogicalName="droneprojecttype",SchemaName="DroneProjectType",CollectionSchemaName="DroneProjectTypes",IsBaseClass=false)]
	[EntityDTO(LogicalName="droneprojecttype",Schema="Kjeldager")]
	public partial class DroneProjectType : DynamicEntity
	{
		public DroneProjectType()
		{
		}

		[DataMember(Name="id")]
		[JsonProperty("id")]
		[JsonPropertyName("id")]
		public Guid Id {get;set;}

		[DataMember(Name="droneprojectid")]
		[JsonProperty("droneprojectid")]
		[JsonPropertyName("droneprojectid")]
		public Guid? DroneProjectId {get;set;}

		[ForeignKey("DroneProjectId")]
		[JsonProperty("droneproject")]
		[JsonPropertyName("droneproject")]
		[DataMember(Name="droneproject")]
		public DroneProject DroneProject {get;set;}

		[DataMember(Name="droneprojecttype")]
		[JsonProperty("droneprojecttype")]
		[JsonPropertyName("droneprojecttype")]
		public DroneProjectTypeValue? DroneProjectTypeValue {get;set;}

	}
}
