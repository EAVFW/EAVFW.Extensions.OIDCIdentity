﻿using EAVFW.Extensions.SecurityModel;
using Kjeldager.Models;
using EAVFW.Extensions.DynamicManifest;
using System;
using EAVFramework.Shared;
using System.Runtime.Serialization;
using Newtonsoft.Json;
using System.Text.Json.Serialization;
namespace Kjeldager.Models
{
	[Serializable()]
	[Entity(LogicalName="project",SchemaName="Project",CollectionSchemaName="Projects",IsBaseClass=true)]
	[EntityDTO(LogicalName="project",Schema="Kjeldager")]
	public partial class Project : BaseOwnerEntity<Identity>, IAuditFields
	{
		public Project()
		{
		}

		[DataMember(Name="name")]
		[JsonProperty("name")]
		[JsonPropertyName("name")]
		[PrimaryField()]
		public String Name {get;set;}

		[DataMember(Name="description")]
		[JsonProperty("description")]
		[JsonPropertyName("description")]
		public String Description {get;set;}

		[DataMember(Name="starttime")]
		[JsonProperty("starttime")]
		[JsonPropertyName("starttime")]
		public DateTime? StartTime {get;set;}

		[DataMember(Name="endtime")]
		[JsonProperty("endtime")]
		[JsonPropertyName("endtime")]
		public DateTime? EndTime {get;set;}

	}
}
