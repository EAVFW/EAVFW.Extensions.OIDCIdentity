﻿using System;
namespace Kjeldager.Models
{
	public enum OpenIdConnectAuthorizationType
	{
		Permanent = 0,
		Adhoc = 1
	}
}
