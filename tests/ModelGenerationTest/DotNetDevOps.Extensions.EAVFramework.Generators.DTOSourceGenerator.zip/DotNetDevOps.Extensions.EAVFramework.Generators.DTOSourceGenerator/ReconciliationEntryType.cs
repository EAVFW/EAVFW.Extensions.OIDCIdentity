﻿using System;
namespace Kjeldager.Models
{
	public enum ReconciliationEntryType
	{
		OCRPayment = 0,
		CardTransfer = 10,
		Cheque = 20,
		DomesticTransfer = 30,
		ForeignTransfer = 40,
		Other = 50,
		DirectDebit = 60,
		DirectDebitReturnOrRefund = 70,
		DirectDebitReversal = 80,
		Mobilepay = 90
	}
}
