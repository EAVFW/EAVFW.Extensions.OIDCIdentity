﻿using EAVFramework;
using System;
using EAVFramework.Shared;
using System.Runtime.Serialization;
using Newtonsoft.Json;
using System.Text.Json.Serialization;
using System.ComponentModel.DataAnnotations.Schema;
using Kjeldager.Models;
using EAVFW.Extensions.OIDCIdentity;

namespace Kjeldager.Models
{
	[Serializable()]
	[Entity(LogicalName="allowedgranttype",SchemaName="AllowedGrantType",CollectionSchemaName="AllowedGrantTypes",IsBaseClass=false)]
	[EntityDTO(LogicalName="allowedgranttype",Schema="Kjeldager")]
	public partial class AllowedGrantType : DynamicEntity, IAllowedGrantType<AllowedGrantTypeValue>
	{
		public AllowedGrantType()
		{
		}

		[DataMember(Name="id")]
		[JsonProperty("id")]
		[JsonPropertyName("id")]
		public Guid Id {get;set;}

		[DataMember(Name="openidconnectclientid")]
		[JsonProperty("openidconnectclientid")]
		[JsonPropertyName("openidconnectclientid")]
		public Guid? OpenIdConnectClientId {get;set;}

		[ForeignKey("OpenIdConnectClientId")]
		[JsonProperty("openidconnectclient")]
		[JsonPropertyName("openidconnectclient")]
		[DataMember(Name="openidconnectclient")]
		public OpenIdConnectClient OpenIdConnectClient {get;set;}

		[DataMember(Name="allowedgranttype")]
		[JsonProperty("allowedgranttype")]
		[JsonPropertyName("allowedgranttype")]
		public AllowedGrantTypeValue? AllowedGrantTypeValue {get;set;}

	}
}
