﻿using EAVFramework;
using System;
using EAVFramework.Shared;
using System.Runtime.Serialization;
using Newtonsoft.Json;
using System.Text.Json.Serialization;
using System.ComponentModel.DataAnnotations.Schema;
using Kjeldager.Models;
using EAVFW.Extensions.OIDCIdentity;

namespace Kjeldager.Models
{
	[Serializable()]
	[Entity(LogicalName="openidconnectauthorizationscope",SchemaName="OpenIdConnectAuthorizationScope",CollectionSchemaName="OpenIdConnectAuthorizationScopes",IsBaseClass=false)]
	[EntityDTO(LogicalName="openidconnectauthorizationscope",Schema="Kjeldager")]
	public partial class OpenIdConnectAuthorizationScope : DynamicEntity, IOpenIdConnectAuthorizationScope<OpenIdConnectIdentityResource>
	{
		public OpenIdConnectAuthorizationScope()
		{
		}

		[DataMember(Name="authorizationid")]
		[JsonProperty("authorizationid")]
		[JsonPropertyName("authorizationid")]
		public Guid? AuthorizationId {get;set;}

		[ForeignKey("AuthorizationId")]
		[JsonProperty("authorization")]
		[JsonPropertyName("authorization")]
		[DataMember(Name="authorization")]
		public OpenIdConnectAuthorization Authorization {get;set;}

		[DataMember(Name="scopeid")]
		[JsonProperty("scopeid")]
		[JsonPropertyName("scopeid")]
		public Guid? ScopeId {get;set;}

		[ForeignKey("ScopeId")]
		[JsonProperty("scope")]
		[JsonPropertyName("scope")]
		[DataMember(Name="scope")]
		public OpenIdConnectIdentityResource Scope {get;set;}

		[DataMember(Name="id")]
		[JsonProperty("id")]
		[JsonPropertyName("id")]
		public Guid Id {get;set;}

	}
}
