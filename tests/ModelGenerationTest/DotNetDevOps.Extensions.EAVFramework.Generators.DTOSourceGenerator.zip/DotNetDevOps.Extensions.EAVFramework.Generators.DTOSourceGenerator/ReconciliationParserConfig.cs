﻿using EAVFW.Extensions.SecurityModel;
using Kjeldager.Models;
using EAVFW.Extensions.DynamicManifest;
using System;
using EAVFramework.Shared;
using System.Runtime.Serialization;
using Newtonsoft.Json;
using System.Text.Json.Serialization;
using System.ComponentModel.DataAnnotations.Schema;
using System.Collections.Generic;
namespace Kjeldager.Models
{
	[Serializable()]
	[Entity(LogicalName="reconciliationparserconfig",SchemaName="ReconciliationParserConfig",CollectionSchemaName="ReconciliationParserConfigs",IsBaseClass=false)]
	[EntityDTO(LogicalName="reconciliationparserconfig",Schema="Kjeldager")]
	public partial class ReconciliationParserConfig : BaseOwnerEntity<Identity>, IAuditFields
	{
		public ReconciliationParserConfig()
		{
		}

		[DataMember(Name="name")]
		[JsonProperty("name")]
		[JsonPropertyName("name")]
		[PrimaryField()]
		public String Name {get;set;}

		[DataMember(Name="configurationid")]
		[JsonProperty("configurationid")]
		[JsonPropertyName("configurationid")]
		public Guid? ConfigurationId {get;set;}

		[ForeignKey("ConfigurationId")]
		[JsonProperty("configuration")]
		[JsonPropertyName("configuration")]
		[DataMember(Name="configuration")]
		public Document Configuration {get;set;}

		[InverseProperty("ParserConfiguration")]
		[JsonProperty("powerconsumptionimports")]
		[JsonPropertyName("powerconsumptionimports")]
		public ICollection<PowerConsumptionImport> PowerConsumptionImports {get;set;}

		[InverseProperty("ParserConfiguration")]
		[JsonProperty("reconciliationsources")]
		[JsonPropertyName("reconciliationsources")]
		public ICollection<ReconciliationSource> ReconciliationSources {get;set;}

	}
}
