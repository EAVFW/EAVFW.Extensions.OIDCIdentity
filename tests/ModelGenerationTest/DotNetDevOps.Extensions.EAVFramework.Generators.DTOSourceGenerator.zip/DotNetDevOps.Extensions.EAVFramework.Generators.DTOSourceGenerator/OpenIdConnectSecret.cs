﻿using EAVFramework;
using System;
using EAVFramework.Shared;
using System.Runtime.Serialization;
using Newtonsoft.Json;
using System.Text.Json.Serialization;
using Kjeldager.Models;
using System.ComponentModel.DataAnnotations.Schema;
namespace Kjeldager.Models
{
	[Serializable()]
	[Entity(LogicalName="openidconnectsecret",SchemaName="OpenIdConnectSecret",CollectionSchemaName="OpenIdConnectSecrets",IsBaseClass=false)]
	[EntityDTO(LogicalName="openidconnectsecret",Schema="Kjeldager")]
	public partial class OpenIdConnectSecret : DynamicEntity
	{
		public OpenIdConnectSecret()
		{
		}

		[DataMember(Name="description")]
		[JsonProperty("description")]
		[JsonPropertyName("description")]
		[PrimaryField()]
		public String Description {get;set;}

		[DataMember(Name="value")]
		[JsonProperty("value")]
		[JsonPropertyName("value")]
		public String Value {get;set;}

		[DataMember(Name="valuehint")]
		[JsonProperty("valuehint")]
		[JsonPropertyName("valuehint")]
		public String ValueHint {get;set;}

		[DataMember(Name="expiration")]
		[JsonProperty("expiration")]
		[JsonPropertyName("expiration")]
		public DateTime? Expiration {get;set;}

		[DataMember(Name="secrettypecode")]
		[JsonProperty("secrettypecode")]
		[JsonPropertyName("secrettypecode")]
		public OpenIdConnectSecretTypeCodes? SecretTypeCode {get;set;}

		[DataMember(Name="apiid")]
		[JsonProperty("apiid")]
		[JsonPropertyName("apiid")]
		public Guid? ApiId {get;set;}

		[ForeignKey("ApiId")]
		[JsonProperty("api")]
		[JsonPropertyName("api")]
		[DataMember(Name="api")]
		public OpenIdConnectAPIResource Api {get;set;}

		[DataMember(Name="clientid")]
		[JsonProperty("clientid")]
		[JsonPropertyName("clientid")]
		public Guid? ClientId {get;set;}

		[ForeignKey("ClientId")]
		[JsonProperty("client")]
		[JsonPropertyName("client")]
		[DataMember(Name="client")]
		public OpenIdConnectClient Client {get;set;}

		[DataMember(Name="id")]
		[JsonProperty("id")]
		[JsonPropertyName("id")]
		public Guid Id {get;set;}

	}
}
