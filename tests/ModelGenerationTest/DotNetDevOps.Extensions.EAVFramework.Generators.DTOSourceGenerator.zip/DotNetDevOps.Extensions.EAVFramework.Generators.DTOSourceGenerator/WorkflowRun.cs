﻿using EAVFW.Extensions.SecurityModel;
using Kjeldager.Models;
using EAVFW.Extensions.DynamicManifest;
using EAVFW.Extensions.WorkflowEngine;
using System;
using EAVFramework.Shared;
using System.Runtime.Serialization;
using Newtonsoft.Json;
using System.Text.Json.Serialization;
namespace Kjeldager.Models
{
	[Serializable()]
	[Entity(LogicalName="workflowrun",SchemaName="WorkflowRun",CollectionSchemaName="WorkflowRuns",IsBaseClass=false)]
	[EntityDTO(LogicalName="workflowrun",Schema="Kjeldager")]
	public partial class WorkflowRun : BaseOwnerEntity<Identity>, IAuditFields, IWorkflowRun
	{
		public WorkflowRun()
		{
		}

		[DataMember(Name="name")]
		[JsonProperty("name")]
		[JsonPropertyName("name")]
		[PrimaryField()]
		public String Name {get;set;}

		[DataMember(Name="state")]
		[JsonProperty("state")]
		[JsonPropertyName("state")]
		public Byte[] State {get;set;}

	}
}
