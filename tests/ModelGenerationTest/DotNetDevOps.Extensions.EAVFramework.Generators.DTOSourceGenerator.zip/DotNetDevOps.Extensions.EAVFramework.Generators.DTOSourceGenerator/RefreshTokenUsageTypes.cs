﻿using System;
namespace Kjeldager.Models
{
	public enum RefreshTokenUsageTypes
	{
		ReUse = 0,
		OneTime = 1
	}
}
