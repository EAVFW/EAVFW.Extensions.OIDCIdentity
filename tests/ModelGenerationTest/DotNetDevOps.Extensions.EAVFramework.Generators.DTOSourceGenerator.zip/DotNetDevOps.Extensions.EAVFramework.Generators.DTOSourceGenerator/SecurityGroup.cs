﻿using Kjeldager.Models;
using EAVFW.Extensions.SecurityModel;
using System;
using EAVFramework.Shared;
using System.Runtime.Serialization;
using Newtonsoft.Json;
using System.Text.Json.Serialization;
using System.ComponentModel.DataAnnotations.Schema;
using System.Collections.Generic;
namespace Kjeldager.Models
{
	[Serializable()]
	[Entity(LogicalName="securitygroup",SchemaName="SecurityGroup",CollectionSchemaName="SecurityGroups",IsBaseClass=false)]
	[EntityDTO(LogicalName="securitygroup",Schema="Kjeldager")]
	public partial class SecurityGroup : Identity, ISecurityGroup
	{
		public SecurityGroup()
		{
		}

		[DataMember(Name="externalid")]
		[JsonProperty("externalid")]
		[JsonPropertyName("externalid")]
		public String ExternalId {get;set;}

		[DataMember(Name="isbusinessunit")]
		[JsonProperty("isbusinessunit")]
		[JsonPropertyName("isbusinessunit")]
		public Boolean? IsBusinessUnit {get;set;}

		[InverseProperty("SecurityGroup")]
		[JsonProperty("securitygroupmembers")]
		[JsonPropertyName("securitygroupmembers")]
		public ICollection<SecurityGroupMember> SecurityGroupMembers {get;set;}

	}
}
