﻿using EAVFW.Extensions.SecurityModel;
using Kjeldager.Models;
using EAVFW.Extensions.DynamicManifest;
using System;
using EAVFramework.Shared;
using System.Runtime.Serialization;
using Newtonsoft.Json;
using System.Text.Json.Serialization;
using System.ComponentModel.DataAnnotations.Schema;
namespace Kjeldager.Models
{
	[Serializable()]
	[Entity(LogicalName="signin",SchemaName="Signin",CollectionSchemaName="Signins",IsBaseClass=false)]
	[EntityDTO(LogicalName="signin",Schema="Kjeldager")]
	public partial class Signin : BaseOwnerEntity<Identity>, IAuditFields
	{
		public Signin()
		{
		}

		[DataMember(Name="identityid")]
		[JsonProperty("identityid")]
		[JsonPropertyName("identityid")]
		public Guid? IdentityId {get;set;}

		[ForeignKey("IdentityId")]
		[JsonProperty("identity")]
		[JsonPropertyName("identity")]
		[DataMember(Name="identity")]
		public Identity Identity {get;set;}

		[DataMember(Name="status")]
		[JsonProperty("status")]
		[JsonPropertyName("status")]
		public SigninStatus? Status {get;set;}

		[DataMember(Name="properties")]
		[JsonProperty("properties")]
		[JsonPropertyName("properties")]
		public String Properties {get;set;}

		[DataMember(Name="claims")]
		[JsonProperty("claims")]
		[JsonPropertyName("claims")]
		public String Claims {get;set;}

		[DataMember(Name="sessionid")]
		[JsonProperty("sessionid")]
		[JsonPropertyName("sessionid")]
		public String SessionId {get;set;}

		[DataMember(Name="provider")]
		[JsonProperty("provider")]
		[JsonPropertyName("provider")]
		public String Provider {get;set;}

	}
}
