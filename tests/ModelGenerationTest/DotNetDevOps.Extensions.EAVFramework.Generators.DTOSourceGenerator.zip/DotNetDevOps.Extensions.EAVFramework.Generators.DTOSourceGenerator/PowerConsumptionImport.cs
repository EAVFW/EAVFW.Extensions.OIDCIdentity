﻿using EAVFW.Extensions.SecurityModel;
using Kjeldager.Models;
using EAVFW.Extensions.DynamicManifest;
using System;
using EAVFramework.Shared;
using System.Runtime.Serialization;
using Newtonsoft.Json;
using System.Text.Json.Serialization;
using System.ComponentModel.DataAnnotations.Schema;
namespace Kjeldager.Models
{
	[Serializable()]
	[Entity(LogicalName="powerconsumptionimport",SchemaName="PowerConsumptionImport",CollectionSchemaName="PowerConsumptionImports",IsBaseClass=false)]
	[EntityDTO(LogicalName="powerconsumptionimport",Schema="Kjeldager")]
	public partial class PowerConsumptionImport : BaseOwnerEntity<Identity>, IAuditFields
	{
		public PowerConsumptionImport()
		{
		}

		[DataMember(Name="name")]
		[JsonProperty("name")]
		[JsonPropertyName("name")]
		[PrimaryField()]
		public String Name {get;set;}

		[DataMember(Name="sourceid")]
		[JsonProperty("sourceid")]
		[JsonPropertyName("sourceid")]
		public Guid? SourceId {get;set;}

		[ForeignKey("SourceId")]
		[JsonProperty("source")]
		[JsonPropertyName("source")]
		[DataMember(Name="source")]
		public Document Source {get;set;}

		[DataMember(Name="parserconfigurationid")]
		[JsonProperty("parserconfigurationid")]
		[JsonPropertyName("parserconfigurationid")]
		public Guid? ParserConfigurationId {get;set;}

		[ForeignKey("ParserConfigurationId")]
		[JsonProperty("parserconfiguration")]
		[JsonPropertyName("parserconfiguration")]
		[DataMember(Name="parserconfiguration")]
		public ReconciliationParserConfig ParserConfiguration {get;set;}

	}
}
