﻿using EAVFW.Extensions.SecurityModel;
using Kjeldager.Models;
using System;
using EAVFramework.Shared;
using System.Runtime.Serialization;
using Newtonsoft.Json;
using System.Text.Json.Serialization;
using System.ComponentModel.DataAnnotations.Schema;
using System.Collections.Generic;
namespace Kjeldager.Models
{
	[Serializable()]
	[Entity(LogicalName="document",SchemaName="Document",CollectionSchemaName="Documents",IsBaseClass=false)]
	[EntityDTO(LogicalName="document",Schema="Kjeldager")]
	public partial class Document : BaseOwnerEntity<Identity>, IAuditFields, IDocumentEntity
	{
		public Document()
		{
		}

		[DataMember(Name="name")]
		[JsonProperty("name")]
		[JsonPropertyName("name")]
		[PrimaryField()]
		public String Name {get;set;}

		[DataMember(Name="size")]
		[JsonProperty("size")]
		[JsonPropertyName("size")]
		public Int32? Size {get;set;}

		[DataMember(Name="container")]
		[JsonProperty("container")]
		[JsonPropertyName("container")]
		public String Container {get;set;}

		[DataMember(Name="path")]
		[JsonProperty("path")]
		[JsonPropertyName("path")]
		public String Path {get;set;}

		[DataMember(Name="contenttype")]
		[JsonProperty("contenttype")]
		[JsonPropertyName("contenttype")]
		public String ContentType {get;set;}

		[DataMember(Name="compressed")]
		[JsonProperty("compressed")]
		[JsonPropertyName("compressed")]
		public Boolean? Compressed {get;set;}

		[DataMember(Name="data")]
		[JsonProperty("data")]
		[JsonPropertyName("data")]
		public Byte[] Data {get;set;}

		[InverseProperty("Content")]
		[JsonProperty("blogposts")]
		[JsonPropertyName("blogposts")]
		public ICollection<BlogPost> BlogPosts {get;set;}

		[InverseProperty("Configuration")]
		[JsonProperty("powerconsumptionimportconfigs")]
		[JsonPropertyName("powerconsumptionimportconfigs")]
		public ICollection<PowerConsumptionImportConfig> PowerConsumptionImportConfigs {get;set;}

		[InverseProperty("Source")]
		[JsonProperty("powerconsumptionimports")]
		[JsonPropertyName("powerconsumptionimports")]
		public ICollection<PowerConsumptionImport> PowerConsumptionImports {get;set;}

		[InverseProperty("Manifest")]
		[JsonProperty("datamodelprojects")]
		[JsonPropertyName("datamodelprojects")]
		public ICollection<DataModelProject> DataModelProjects {get;set;}

		[InverseProperty("Configuration")]
		[JsonProperty("reconciliationparserconfigs")]
		[JsonPropertyName("reconciliationparserconfigs")]
		public ICollection<ReconciliationParserConfig> ReconciliationParserConfigs {get;set;}

		[InverseProperty("Data")]
		[JsonProperty("reconciliationsources")]
		[JsonPropertyName("reconciliationsources")]
		public ICollection<ReconciliationSource> ReconciliationSources {get;set;}

	}
}
