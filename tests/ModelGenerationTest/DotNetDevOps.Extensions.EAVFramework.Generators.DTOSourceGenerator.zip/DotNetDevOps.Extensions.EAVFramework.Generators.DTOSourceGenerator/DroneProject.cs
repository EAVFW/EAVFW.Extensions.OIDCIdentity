﻿using Kjeldager.Models;
using System;
using EAVFramework.Shared;
using System.ComponentModel.DataAnnotations.Schema;
using Newtonsoft.Json;
using System.Text.Json.Serialization;
using System.Collections.Generic;
namespace Kjeldager.Models
{
	[Serializable()]
	[Entity(LogicalName="droneproject",SchemaName="DroneProject",CollectionSchemaName="DroneProjects",IsBaseClass=false)]
	[EntityDTO(LogicalName="droneproject",Schema="Kjeldager")]
	public partial class DroneProject : Project
	{
		public DroneProject()
		{
		}

		[InverseProperty("DroneProject")]
		[JsonProperty("droneprojecttypes")]
		[JsonPropertyName("droneprojecttypes")]
		public ICollection<DroneProjectType> DroneProjectTypes {get;set;}

	}
}
