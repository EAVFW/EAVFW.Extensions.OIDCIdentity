﻿using Kjeldager.Models;
using System;
using EAVFramework.Shared;
using System.Runtime.Serialization;
using Newtonsoft.Json;
using System.Text.Json.Serialization;
using EAVFW.Extensions.OIDCIdentity;

namespace Kjeldager.Models
{
	[Serializable()]
	[Entity(LogicalName="openidconnectscope",SchemaName="OpenIdConnectScope",CollectionSchemaName="OpenIdConnectScopes",IsBaseClass=false)]
	[EntityDTO(LogicalName="openidconnectscope",Schema="Kjeldager")]
	public partial class OpenIdConnectScope : OpenIdConnectResource, IOpenIdConnectScope<OpenIdConnectScopeResource, OpenIdConnectResource, OpenIdConnectIdentityResource>
	{
		public OpenIdConnectScope()
		{
		}

		[DataMember(Name="required")]
		[JsonProperty("required")]
		[JsonPropertyName("required")]
		public Boolean? Required {get;set;}

		[DataMember(Name="emphasize")]
		[JsonProperty("emphasize")]
		[JsonPropertyName("emphasize")]
		public Boolean? Emphasize {get;set;}

	}
}
