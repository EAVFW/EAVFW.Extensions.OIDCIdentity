﻿using System;
namespace Kjeldager.Models
{
	public enum RefreshTokenExpirationTypes
	{
		Sliding = 0,
		Absolute = 1
	}
}
