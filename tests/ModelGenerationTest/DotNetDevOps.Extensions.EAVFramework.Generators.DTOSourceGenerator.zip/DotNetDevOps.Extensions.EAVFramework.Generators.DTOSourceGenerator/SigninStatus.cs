﻿using System;
namespace Kjeldager.Models
{
	public enum SigninStatus
	{
		Approved = 0,
		Rejected = 1,
		Used = 2
	}
}
