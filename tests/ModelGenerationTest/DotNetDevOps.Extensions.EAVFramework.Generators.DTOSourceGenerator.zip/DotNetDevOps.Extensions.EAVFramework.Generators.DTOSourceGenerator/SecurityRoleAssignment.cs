﻿using EAVFW.Extensions.SecurityModel;
using Kjeldager.Models;
using EAVFW.Extensions.DynamicManifest;
using System;
using EAVFramework.Shared;
using System.Runtime.Serialization;
using Newtonsoft.Json;
using System.Text.Json.Serialization;
using System.ComponentModel.DataAnnotations.Schema;
namespace Kjeldager.Models
{
	[Serializable()]
	[Entity(LogicalName="securityroleassignment",SchemaName="SecurityRoleAssignment",CollectionSchemaName="SecurityRoleAssignments",IsBaseClass=false)]
	[EntityDTO(LogicalName="securityroleassignment",Schema="Kjeldager")]
	public partial class SecurityRoleAssignment : BaseOwnerEntity<Identity>, ISecurityRoleAssignment, IAuditFields
	{
		public SecurityRoleAssignment()
		{
		}

		[DataMember(Name="identityid")]
		[JsonProperty("identityid")]
		[JsonPropertyName("identityid")]
		public Guid? IdentityId {get;set;}

		[ForeignKey("IdentityId")]
		[JsonProperty("identity")]
		[JsonPropertyName("identity")]
		[DataMember(Name="identity")]
		public Identity Identity {get;set;}

		[DataMember(Name="securityroleid")]
		[JsonProperty("securityroleid")]
		[JsonPropertyName("securityroleid")]
		public Guid? SecurityRoleId {get;set;}

		[ForeignKey("SecurityRoleId")]
		[JsonProperty("securityrole")]
		[JsonPropertyName("securityrole")]
		[DataMember(Name="securityrole")]
		public SecurityRole SecurityRole {get;set;}

	}
}
