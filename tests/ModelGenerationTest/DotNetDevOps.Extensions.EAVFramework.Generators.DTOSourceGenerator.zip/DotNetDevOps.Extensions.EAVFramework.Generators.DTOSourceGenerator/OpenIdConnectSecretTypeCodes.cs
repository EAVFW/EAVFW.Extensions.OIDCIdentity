﻿using System;
namespace Kjeldager.Models
{
	public enum OpenIdConnectSecretTypeCodes
	{
		SharedSecret = 0,
		X509CertificateThumbprint = 1,
		X509CertificateName = 2,
		X509CertificateBase65 = 3,
		JsonWebKey = 4
	}
}
