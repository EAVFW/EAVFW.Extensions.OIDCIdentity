﻿using EAVFramework;
using System;
using EAVFramework.Shared;
using System.Runtime.Serialization;
using Newtonsoft.Json;
using System.Text.Json.Serialization;
using Kjeldager.Models;
using System.ComponentModel.DataAnnotations.Schema;
namespace Kjeldager.Models
{
	[Serializable()]
	[Entity(LogicalName="powerconsumptionentry",SchemaName="PowerConsumptionEntry",CollectionSchemaName="PowerConsumptionEntries",IsBaseClass=false)]
	[EntityDTO(LogicalName="powerconsumptionentry",Schema="Kjeldager")]
	public partial class PowerConsumptionEntry : DynamicEntity
	{
		public PowerConsumptionEntry()
		{
		}

		[DataMember(Name="value")]
		[JsonProperty("value")]
		[JsonPropertyName("value")]
		[PrimaryField()]
		public Decimal? Value {get;set;}

		[DataMember(Name="unittype")]
		[JsonProperty("unittype")]
		[JsonPropertyName("unittype")]
		public PowerConsumptionEntryUnitTypes? UnitType {get;set;}

		[DataMember(Name="readingtype")]
		[JsonProperty("readingtype")]
		[JsonPropertyName("readingtype")]
		public PowerConsumptionEntryReadingType? ReadingType {get;set;}

		[DataMember(Name="starttime")]
		[JsonProperty("starttime")]
		[JsonPropertyName("starttime")]
		public DateTime? StartTime {get;set;}

		[DataMember(Name="endtime")]
		[JsonProperty("endtime")]
		[JsonPropertyName("endtime")]
		public DateTime? EndTime {get;set;}

		[DataMember(Name="powermeterid")]
		[JsonProperty("powermeterid")]
		[JsonPropertyName("powermeterid")]
		public Guid? PowerMeterId {get;set;}

		[ForeignKey("PowerMeterId")]
		[JsonProperty("powermeter")]
		[JsonPropertyName("powermeter")]
		[DataMember(Name="powermeter")]
		public PowerMeter PowerMeter {get;set;}

		[DataMember(Name="id")]
		[JsonProperty("id")]
		[JsonPropertyName("id")]
		public Guid Id {get;set;}

	}
}
