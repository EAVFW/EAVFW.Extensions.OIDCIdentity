﻿using System;
namespace Kjeldager.Models
{
	public enum AccessTokenTypes
	{
		JWT = 0,
		Reference = 1
	}
}
