﻿using EAVFramework;
using System;
using EAVFramework.Shared;
using System.Runtime.Serialization;
using Newtonsoft.Json;
using System.Text.Json.Serialization;
using System.ComponentModel.DataAnnotations.Schema;
using System.Collections.Generic;
using Kjeldager.Models;
namespace Kjeldager.Models
{
	[Serializable()]
	[Entity(LogicalName="currency",SchemaName="Currency",CollectionSchemaName="Currencies",IsBaseClass=false)]
	[EntityDTO(LogicalName="currency",Schema="Kjeldager")]
	public partial class Currency : DynamicEntity
	{
		public Currency()
		{
		}

		[DataMember(Name="currencyname")]
		[JsonProperty("currencyname")]
		[JsonPropertyName("currencyname")]
		[PrimaryField()]
		public String CurrencyName {get;set;}

		[DataMember(Name="currencyprecision")]
		[JsonProperty("currencyprecision")]
		[JsonPropertyName("currencyprecision")]
		public Int32? CurrencyPrecision {get;set;}

		[DataMember(Name="isocurrencycode")]
		[JsonProperty("isocurrencycode")]
		[JsonPropertyName("isocurrencycode")]
		public String ISOCurrencyCode {get;set;}

		[DataMember(Name="currencysymbol")]
		[JsonProperty("currencysymbol")]
		[JsonPropertyName("currencysymbol")]
		public String CurrencySymbol {get;set;}

		[DataMember(Name="id")]
		[JsonProperty("id")]
		[JsonPropertyName("id")]
		public Guid Id {get;set;}

		[InverseProperty("AmountCurrency")]
		[JsonProperty("reconciliationaccounts")]
		[JsonPropertyName("reconciliationaccounts")]
		public ICollection<ReconciliationAccount> ReconciliationAccounts {get;set;}

		[InverseProperty("AmountCurrency")]
		[JsonProperty("amountcurrencyreconciliationentries")]
		[JsonPropertyName("amountcurrencyreconciliationentries")]
		public ICollection<ReconciliationEntry> AmountCurrencyReconciliationEntries {get;set;}

		[InverseProperty("OriginalAmountCurrency")]
		[JsonProperty("originalamountcurrencyreconciliationentries")]
		[JsonPropertyName("originalamountcurrencyreconciliationentries")]
		public ICollection<ReconciliationEntry> OriginalAmountCurrencyReconciliationEntries {get;set;}

		[InverseProperty("FeeCurrency")]
		[JsonProperty("feecurrencyreconciliationentries")]
		[JsonPropertyName("feecurrencyreconciliationentries")]
		public ICollection<ReconciliationEntry> FeeCurrencyReconciliationEntries {get;set;}

		[InverseProperty("BalanceCurrency")]
		[JsonProperty("balancecurrencyreconciliationentries")]
		[JsonPropertyName("balancecurrencyreconciliationentries")]
		public ICollection<ReconciliationEntry> BalanceCurrencyReconciliationEntries {get;set;}

	}
}
