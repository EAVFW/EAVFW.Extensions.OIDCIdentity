﻿using EAVFW.Extensions.SecurityModel;
using Kjeldager.Models;
using EAVFW.Extensions.DynamicManifest;
using System;
using EAVFramework.Shared;
using System.Runtime.Serialization;
using Newtonsoft.Json;
using System.Text.Json.Serialization;
using System.ComponentModel.DataAnnotations.Schema;
namespace Kjeldager.Models
{
	[Serializable()]
	[Entity(LogicalName="securityrolepermission",SchemaName="SecurityRolePermission",CollectionSchemaName="SecurityRolePermissions",IsBaseClass=false)]
	[EntityDTO(LogicalName="securityrolepermission",Schema="Kjeldager")]
	public partial class SecurityRolePermission : BaseOwnerEntity<Identity>, ISecurityRolePermission, IAuditFields
	{
		public SecurityRolePermission()
		{
		}

		[DataMember(Name="name")]
		[JsonProperty("name")]
		[JsonPropertyName("name")]
		[PrimaryField()]
		public String Name {get;set;}

		[DataMember(Name="permissionid")]
		[JsonProperty("permissionid")]
		[JsonPropertyName("permissionid")]
		public Guid? PermissionId {get;set;}

		[ForeignKey("PermissionId")]
		[JsonProperty("permission")]
		[JsonPropertyName("permission")]
		[DataMember(Name="permission")]
		public Permission Permission {get;set;}

		[DataMember(Name="securityroleid")]
		[JsonProperty("securityroleid")]
		[JsonPropertyName("securityroleid")]
		public Guid? SecurityRoleId {get;set;}

		[ForeignKey("SecurityRoleId")]
		[JsonProperty("securityrole")]
		[JsonPropertyName("securityrole")]
		[DataMember(Name="securityrole")]
		public SecurityRole SecurityRole {get;set;}

	}
}
