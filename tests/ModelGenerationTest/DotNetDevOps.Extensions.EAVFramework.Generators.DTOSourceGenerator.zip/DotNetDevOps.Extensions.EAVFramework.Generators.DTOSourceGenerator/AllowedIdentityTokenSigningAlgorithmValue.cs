﻿using System;
namespace Kjeldager.Models
{
	public enum AllowedIdentityTokenSigningAlgorithmValue
	{
		ES256 = 1
	}
}
