﻿using EAVFW.Extensions.SecurityModel;
using Kjeldager.Models;
using EAVFW.Extensions.DynamicManifest;
using System;
using EAVFramework.Shared;
using System.Runtime.Serialization;
using Newtonsoft.Json;
using System.Text.Json.Serialization;
using System.ComponentModel.DataAnnotations.Schema;
using System.Collections.Generic;
namespace Kjeldager.Models
{
	[Serializable()]
	[Entity(LogicalName="securityrole",SchemaName="SecurityRole",CollectionSchemaName="SecurityRoles",IsBaseClass=false)]
	[EntityDTO(LogicalName="securityrole",Schema="Kjeldager")]
	public partial class SecurityRole : BaseOwnerEntity<Identity>, ISecurityRole, IAuditFields
	{
		public SecurityRole()
		{
		}

		[DataMember(Name="name")]
		[JsonProperty("name")]
		[JsonPropertyName("name")]
		[PrimaryField()]
		public String Name {get;set;}

		[DataMember(Name="description")]
		[JsonProperty("description")]
		[JsonPropertyName("description")]
		public String Description {get;set;}

		[InverseProperty("SecurityRole")]
		[JsonProperty("securityrolepermissions")]
		[JsonPropertyName("securityrolepermissions")]
		public ICollection<SecurityRolePermission> SecurityRolePermissions {get;set;}

		[InverseProperty("SecurityRole")]
		[JsonProperty("securityroleassignments")]
		[JsonPropertyName("securityroleassignments")]
		public ICollection<SecurityRoleAssignment> SecurityRoleAssignments {get;set;}

	}
}
