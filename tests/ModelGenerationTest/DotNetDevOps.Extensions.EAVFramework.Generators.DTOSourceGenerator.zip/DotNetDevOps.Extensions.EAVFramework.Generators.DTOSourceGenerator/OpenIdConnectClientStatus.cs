﻿using System;
namespace Kjeldager.Models
{
	public enum OpenIdConnectClientStatus
	{
		Inactive = 0,
		Enabled = 1,
		Draft = 2
	}
}
