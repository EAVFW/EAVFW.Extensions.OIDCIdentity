﻿using System;
namespace Kjeldager.Models
{
	public enum ProtocolTypes
	{
		Openidconnect = 0
	}
}
