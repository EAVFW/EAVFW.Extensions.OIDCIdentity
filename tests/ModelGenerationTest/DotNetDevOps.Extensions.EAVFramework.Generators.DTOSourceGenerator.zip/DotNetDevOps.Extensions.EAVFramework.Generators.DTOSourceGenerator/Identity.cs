﻿using EAVFW.Extensions.SecurityModel;
using Kjeldager.Models;
using EAVFW.Extensions.DynamicManifest;
using System;
using EAVFramework.Shared;
using System.Runtime.Serialization;
using Newtonsoft.Json;
using System.Text.Json.Serialization;
using System.ComponentModel.DataAnnotations.Schema;
using System.Collections.Generic;
namespace Kjeldager.Models
{
	[Serializable()]
	[Entity(LogicalName="identity",SchemaName="Identity",CollectionSchemaName="Identities",IsBaseClass=true)]
	[EntityDTO(LogicalName="identity",Schema="Kjeldager")]
	public partial class Identity : BaseOwnerEntity<Identity>, IIdentity, IAuditFields
	{
		public Identity()
		{
		}

		[DataMember(Name="name")]
		[JsonProperty("name")]
		[JsonPropertyName("name")]
		[PrimaryField()]
		public String Name {get;set;}

		[InverseProperty("Owner")]
		[JsonProperty("ownerservers")]
		[JsonPropertyName("ownerservers")]
		public ICollection<Server> OwnerServers {get;set;}

		[InverseProperty("ModifiedBy")]
		[JsonProperty("modifiedbyservers")]
		[JsonPropertyName("modifiedbyservers")]
		public ICollection<Server> ModifiedByServers {get;set;}

		[InverseProperty("CreatedBy")]
		[JsonProperty("createdbyservers")]
		[JsonPropertyName("createdbyservers")]
		public ICollection<Server> CreatedByServers {get;set;}

		[InverseProperty("Owner")]
		[JsonProperty("ownerenvironmentvariables")]
		[JsonPropertyName("ownerenvironmentvariables")]
		public ICollection<EnvironmentVariable> OwnerEnvironmentVariables {get;set;}

		[InverseProperty("ModifiedBy")]
		[JsonProperty("modifiedbyenvironmentvariables")]
		[JsonPropertyName("modifiedbyenvironmentvariables")]
		public ICollection<EnvironmentVariable> ModifiedByEnvironmentVariables {get;set;}

		[InverseProperty("CreatedBy")]
		[JsonProperty("createdbyenvironmentvariables")]
		[JsonPropertyName("createdbyenvironmentvariables")]
		public ICollection<EnvironmentVariable> CreatedByEnvironmentVariables {get;set;}

		[InverseProperty("Owner")]
		[JsonProperty("owneridentities")]
		[JsonPropertyName("owneridentities")]
		public ICollection<Identity> OwnerIdentities {get;set;}

		[InverseProperty("ModifiedBy")]
		[JsonProperty("modifiedbyidentities")]
		[JsonPropertyName("modifiedbyidentities")]
		public ICollection<Identity> ModifiedByIdentities {get;set;}

		[InverseProperty("CreatedBy")]
		[JsonProperty("createdbyidentities")]
		[JsonPropertyName("createdbyidentities")]
		public ICollection<Identity> CreatedByIdentities {get;set;}

		[InverseProperty("Owner")]
		[JsonProperty("ownerdocuments")]
		[JsonPropertyName("ownerdocuments")]
		public ICollection<Document> OwnerDocuments {get;set;}

		[InverseProperty("ModifiedBy")]
		[JsonProperty("modifiedbydocuments")]
		[JsonPropertyName("modifiedbydocuments")]
		public ICollection<Document> ModifiedByDocuments {get;set;}

		[InverseProperty("CreatedBy")]
		[JsonProperty("createdbydocuments")]
		[JsonPropertyName("createdbydocuments")]
		public ICollection<Document> CreatedByDocuments {get;set;}

		[InverseProperty("Owner")]
		[JsonProperty("ownerpermissions")]
		[JsonPropertyName("ownerpermissions")]
		public ICollection<Permission> OwnerPermissions {get;set;}

		[InverseProperty("ModifiedBy")]
		[JsonProperty("modifiedbypermissions")]
		[JsonPropertyName("modifiedbypermissions")]
		public ICollection<Permission> ModifiedByPermissions {get;set;}

		[InverseProperty("CreatedBy")]
		[JsonProperty("createdbypermissions")]
		[JsonPropertyName("createdbypermissions")]
		public ICollection<Permission> CreatedByPermissions {get;set;}

		[InverseProperty("Owner")]
		[JsonProperty("ownersecurityroles")]
		[JsonPropertyName("ownersecurityroles")]
		public ICollection<SecurityRole> OwnerSecurityRoles {get;set;}

		[InverseProperty("ModifiedBy")]
		[JsonProperty("modifiedbysecurityroles")]
		[JsonPropertyName("modifiedbysecurityroles")]
		public ICollection<SecurityRole> ModifiedBySecurityRoles {get;set;}

		[InverseProperty("CreatedBy")]
		[JsonProperty("createdbysecurityroles")]
		[JsonPropertyName("createdbysecurityroles")]
		public ICollection<SecurityRole> CreatedBySecurityRoles {get;set;}

		[InverseProperty("Owner")]
		[JsonProperty("ownersecurityrolepermissions")]
		[JsonPropertyName("ownersecurityrolepermissions")]
		public ICollection<SecurityRolePermission> OwnerSecurityRolePermissions {get;set;}

		[InverseProperty("ModifiedBy")]
		[JsonProperty("modifiedbysecurityrolepermissions")]
		[JsonPropertyName("modifiedbysecurityrolepermissions")]
		public ICollection<SecurityRolePermission> ModifiedBySecurityRolePermissions {get;set;}

		[InverseProperty("CreatedBy")]
		[JsonProperty("createdbysecurityrolepermissions")]
		[JsonPropertyName("createdbysecurityrolepermissions")]
		public ICollection<SecurityRolePermission> CreatedBySecurityRolePermissions {get;set;}

		[InverseProperty("Identity")]
		[JsonProperty("identitysecurityroleassignments")]
		[JsonPropertyName("identitysecurityroleassignments")]
		public ICollection<SecurityRoleAssignment> IdentitySecurityRoleAssignments {get;set;}

		[InverseProperty("Owner")]
		[JsonProperty("ownersecurityroleassignments")]
		[JsonPropertyName("ownersecurityroleassignments")]
		public ICollection<SecurityRoleAssignment> OwnerSecurityRoleAssignments {get;set;}

		[InverseProperty("ModifiedBy")]
		[JsonProperty("modifiedbysecurityroleassignments")]
		[JsonPropertyName("modifiedbysecurityroleassignments")]
		public ICollection<SecurityRoleAssignment> ModifiedBySecurityRoleAssignments {get;set;}

		[InverseProperty("CreatedBy")]
		[JsonProperty("createdbysecurityroleassignments")]
		[JsonPropertyName("createdbysecurityroleassignments")]
		public ICollection<SecurityRoleAssignment> CreatedBySecurityRoleAssignments {get;set;}

		[InverseProperty("Identity")]
		[JsonProperty("identitysecuritygroupmembers")]
		[JsonPropertyName("identitysecuritygroupmembers")]
		public ICollection<SecurityGroupMember> IdentitySecurityGroupMembers {get;set;}

		[InverseProperty("Owner")]
		[JsonProperty("ownersecuritygroupmembers")]
		[JsonPropertyName("ownersecuritygroupmembers")]
		public ICollection<SecurityGroupMember> OwnerSecurityGroupMembers {get;set;}

		[InverseProperty("ModifiedBy")]
		[JsonProperty("modifiedbysecuritygroupmembers")]
		[JsonPropertyName("modifiedbysecuritygroupmembers")]
		public ICollection<SecurityGroupMember> ModifiedBySecurityGroupMembers {get;set;}

		[InverseProperty("CreatedBy")]
		[JsonProperty("createdbysecuritygroupmembers")]
		[JsonPropertyName("createdbysecuritygroupmembers")]
		public ICollection<SecurityGroupMember> CreatedBySecurityGroupMembers {get;set;}

		[InverseProperty("Owner")]
		[JsonProperty("ownerrecordshares")]
		[JsonPropertyName("ownerrecordshares")]
		public ICollection<RecordShare> OwnerRecordShares {get;set;}

		[InverseProperty("ModifiedBy")]
		[JsonProperty("modifiedbyrecordshares")]
		[JsonPropertyName("modifiedbyrecordshares")]
		public ICollection<RecordShare> ModifiedByRecordShares {get;set;}

		[InverseProperty("CreatedBy")]
		[JsonProperty("createdbyrecordshares")]
		[JsonPropertyName("createdbyrecordshares")]
		public ICollection<RecordShare> CreatedByRecordShares {get;set;}

		[InverseProperty("Identity")]
		[JsonProperty("identitysignins")]
		[JsonPropertyName("identitysignins")]
		public ICollection<Signin> IdentitySignins {get;set;}

		[InverseProperty("Owner")]
		[JsonProperty("ownersignins")]
		[JsonPropertyName("ownersignins")]
		public ICollection<Signin> OwnerSignins {get;set;}

		[InverseProperty("ModifiedBy")]
		[JsonProperty("modifiedbysignins")]
		[JsonPropertyName("modifiedbysignins")]
		public ICollection<Signin> ModifiedBySignins {get;set;}

		[InverseProperty("CreatedBy")]
		[JsonProperty("createdbysignins")]
		[JsonPropertyName("createdbysignins")]
		public ICollection<Signin> CreatedBySignins {get;set;}

		[InverseProperty("Owner")]
		[JsonProperty("ownerworkflowruns")]
		[JsonPropertyName("ownerworkflowruns")]
		public ICollection<WorkflowRun> OwnerWorkflowRuns {get;set;}

		[InverseProperty("ModifiedBy")]
		[JsonProperty("modifiedbyworkflowruns")]
		[JsonPropertyName("modifiedbyworkflowruns")]
		public ICollection<WorkflowRun> ModifiedByWorkflowRuns {get;set;}

		[InverseProperty("CreatedBy")]
		[JsonProperty("createdbyworkflowruns")]
		[JsonPropertyName("createdbyworkflowruns")]
		public ICollection<WorkflowRun> CreatedByWorkflowRuns {get;set;}

		[InverseProperty("Owner")]
		[JsonProperty("ownerblogtags")]
		[JsonPropertyName("ownerblogtags")]
		public ICollection<BlogTag> OwnerBlogTags {get;set;}

		[InverseProperty("ModifiedBy")]
		[JsonProperty("modifiedbyblogtags")]
		[JsonPropertyName("modifiedbyblogtags")]
		public ICollection<BlogTag> ModifiedByBlogTags {get;set;}

		[InverseProperty("CreatedBy")]
		[JsonProperty("createdbyblogtags")]
		[JsonPropertyName("createdbyblogtags")]
		public ICollection<BlogTag> CreatedByBlogTags {get;set;}

		[InverseProperty("Owner")]
		[JsonProperty("ownerblogposts")]
		[JsonPropertyName("ownerblogposts")]
		public ICollection<BlogPost> OwnerBlogPosts {get;set;}

		[InverseProperty("ModifiedBy")]
		[JsonProperty("modifiedbyblogposts")]
		[JsonPropertyName("modifiedbyblogposts")]
		public ICollection<BlogPost> ModifiedByBlogPosts {get;set;}

		[InverseProperty("CreatedBy")]
		[JsonProperty("createdbyblogposts")]
		[JsonPropertyName("createdbyblogposts")]
		public ICollection<BlogPost> CreatedByBlogPosts {get;set;}

		[InverseProperty("Owner")]
		[JsonProperty("ownerblogposttags")]
		[JsonPropertyName("ownerblogposttags")]
		public ICollection<BlogPostTag> OwnerBlogPostTags {get;set;}

		[InverseProperty("ModifiedBy")]
		[JsonProperty("modifiedbyblogposttags")]
		[JsonPropertyName("modifiedbyblogposttags")]
		public ICollection<BlogPostTag> ModifiedByBlogPostTags {get;set;}

		[InverseProperty("CreatedBy")]
		[JsonProperty("createdbyblogposttags")]
		[JsonPropertyName("createdbyblogposttags")]
		public ICollection<BlogPostTag> CreatedByBlogPostTags {get;set;}

		[InverseProperty("Subject")]
		[JsonProperty("subjectopenidconnectauthorizations")]
		[JsonPropertyName("subjectopenidconnectauthorizations")]
		public ICollection<OpenIdConnectAuthorization> SubjectOpenIdConnectAuthorizations {get;set;}

		[InverseProperty("Owner")]
		[JsonProperty("owneropenidconnectauthorizations")]
		[JsonPropertyName("owneropenidconnectauthorizations")]
		public ICollection<OpenIdConnectAuthorization> OwnerOpenIdConnectAuthorizations {get;set;}

		[InverseProperty("ModifiedBy")]
		[JsonProperty("modifiedbyopenidconnectauthorizations")]
		[JsonPropertyName("modifiedbyopenidconnectauthorizations")]
		public ICollection<OpenIdConnectAuthorization> ModifiedByOpenIdConnectAuthorizations {get;set;}

		[InverseProperty("CreatedBy")]
		[JsonProperty("createdbyopenidconnectauthorizations")]
		[JsonPropertyName("createdbyopenidconnectauthorizations")]
		public ICollection<OpenIdConnectAuthorization> CreatedByOpenIdConnectAuthorizations {get;set;}

		[InverseProperty("Subject")]
		[JsonProperty("subjectopenidconnecttokens")]
		[JsonPropertyName("subjectopenidconnecttokens")]
		public ICollection<OpenIdConnectToken> SubjectOpenIdConnectTokens {get;set;}

		[InverseProperty("Owner")]
		[JsonProperty("owneropenidconnecttokens")]
		[JsonPropertyName("owneropenidconnecttokens")]
		public ICollection<OpenIdConnectToken> OwnerOpenIdConnectTokens {get;set;}

		[InverseProperty("ModifiedBy")]
		[JsonProperty("modifiedbyopenidconnecttokens")]
		[JsonPropertyName("modifiedbyopenidconnecttokens")]
		public ICollection<OpenIdConnectToken> ModifiedByOpenIdConnectTokens {get;set;}

		[InverseProperty("CreatedBy")]
		[JsonProperty("createdbyopenidconnecttokens")]
		[JsonPropertyName("createdbyopenidconnecttokens")]
		public ICollection<OpenIdConnectToken> CreatedByOpenIdConnectTokens {get;set;}

		[InverseProperty("Owner")]
		[JsonProperty("owneropenidconnectresources")]
		[JsonPropertyName("owneropenidconnectresources")]
		public ICollection<OpenIdConnectResource> OwnerOpenIdConnectResources {get;set;}

		[InverseProperty("ModifiedBy")]
		[JsonProperty("modifiedbyopenidconnectresources")]
		[JsonPropertyName("modifiedbyopenidconnectresources")]
		public ICollection<OpenIdConnectResource> ModifiedByOpenIdConnectResources {get;set;}

		[InverseProperty("CreatedBy")]
		[JsonProperty("createdbyopenidconnectresources")]
		[JsonPropertyName("createdbyopenidconnectresources")]
		public ICollection<OpenIdConnectResource> CreatedByOpenIdConnectResources {get;set;}

		[InverseProperty("Owner")]
		[JsonProperty("ownerpowerconsumptionimportconfigs")]
		[JsonPropertyName("ownerpowerconsumptionimportconfigs")]
		public ICollection<PowerConsumptionImportConfig> OwnerPowerConsumptionImportConfigs {get;set;}

		[InverseProperty("ModifiedBy")]
		[JsonProperty("modifiedbypowerconsumptionimportconfigs")]
		[JsonPropertyName("modifiedbypowerconsumptionimportconfigs")]
		public ICollection<PowerConsumptionImportConfig> ModifiedByPowerConsumptionImportConfigs {get;set;}

		[InverseProperty("CreatedBy")]
		[JsonProperty("createdbypowerconsumptionimportconfigs")]
		[JsonPropertyName("createdbypowerconsumptionimportconfigs")]
		public ICollection<PowerConsumptionImportConfig> CreatedByPowerConsumptionImportConfigs {get;set;}

		[InverseProperty("Owner")]
		[JsonProperty("ownerpowerconsumptionimports")]
		[JsonPropertyName("ownerpowerconsumptionimports")]
		public ICollection<PowerConsumptionImport> OwnerPowerConsumptionImports {get;set;}

		[InverseProperty("ModifiedBy")]
		[JsonProperty("modifiedbypowerconsumptionimports")]
		[JsonPropertyName("modifiedbypowerconsumptionimports")]
		public ICollection<PowerConsumptionImport> ModifiedByPowerConsumptionImports {get;set;}

		[InverseProperty("CreatedBy")]
		[JsonProperty("createdbypowerconsumptionimports")]
		[JsonPropertyName("createdbypowerconsumptionimports")]
		public ICollection<PowerConsumptionImport> CreatedByPowerConsumptionImports {get;set;}

		[InverseProperty("Owner")]
		[JsonProperty("ownerprojects")]
		[JsonPropertyName("ownerprojects")]
		public ICollection<Project> OwnerProjects {get;set;}

		[InverseProperty("ModifiedBy")]
		[JsonProperty("modifiedbyprojects")]
		[JsonPropertyName("modifiedbyprojects")]
		public ICollection<Project> ModifiedByProjects {get;set;}

		[InverseProperty("CreatedBy")]
		[JsonProperty("createdbyprojects")]
		[JsonPropertyName("createdbyprojects")]
		public ICollection<Project> CreatedByProjects {get;set;}

		[InverseProperty("Owner")]
		[JsonProperty("ownerreconciliationaccounts")]
		[JsonPropertyName("ownerreconciliationaccounts")]
		public ICollection<ReconciliationAccount> OwnerReconciliationAccounts {get;set;}

		[InverseProperty("ModifiedBy")]
		[JsonProperty("modifiedbyreconciliationaccounts")]
		[JsonPropertyName("modifiedbyreconciliationaccounts")]
		public ICollection<ReconciliationAccount> ModifiedByReconciliationAccounts {get;set;}

		[InverseProperty("CreatedBy")]
		[JsonProperty("createdbyreconciliationaccounts")]
		[JsonPropertyName("createdbyreconciliationaccounts")]
		public ICollection<ReconciliationAccount> CreatedByReconciliationAccounts {get;set;}

		[InverseProperty("Owner")]
		[JsonProperty("ownerreconciliationentries")]
		[JsonPropertyName("ownerreconciliationentries")]
		public ICollection<ReconciliationEntry> OwnerReconciliationEntries {get;set;}

		[InverseProperty("ModifiedBy")]
		[JsonProperty("modifiedbyreconciliationentries")]
		[JsonPropertyName("modifiedbyreconciliationentries")]
		public ICollection<ReconciliationEntry> ModifiedByReconciliationEntries {get;set;}

		[InverseProperty("CreatedBy")]
		[JsonProperty("createdbyreconciliationentries")]
		[JsonPropertyName("createdbyreconciliationentries")]
		public ICollection<ReconciliationEntry> CreatedByReconciliationEntries {get;set;}

		[InverseProperty("Owner")]
		[JsonProperty("ownerreconciliationparserconfigs")]
		[JsonPropertyName("ownerreconciliationparserconfigs")]
		public ICollection<ReconciliationParserConfig> OwnerReconciliationParserConfigs {get;set;}

		[InverseProperty("ModifiedBy")]
		[JsonProperty("modifiedbyreconciliationparserconfigs")]
		[JsonPropertyName("modifiedbyreconciliationparserconfigs")]
		public ICollection<ReconciliationParserConfig> ModifiedByReconciliationParserConfigs {get;set;}

		[InverseProperty("CreatedBy")]
		[JsonProperty("createdbyreconciliationparserconfigs")]
		[JsonPropertyName("createdbyreconciliationparserconfigs")]
		public ICollection<ReconciliationParserConfig> CreatedByReconciliationParserConfigs {get;set;}

		[InverseProperty("Owner")]
		[JsonProperty("ownerreconciliationsources")]
		[JsonPropertyName("ownerreconciliationsources")]
		public ICollection<ReconciliationSource> OwnerReconciliationSources {get;set;}

		[InverseProperty("ModifiedBy")]
		[JsonProperty("modifiedbyreconciliationsources")]
		[JsonPropertyName("modifiedbyreconciliationsources")]
		public ICollection<ReconciliationSource> ModifiedByReconciliationSources {get;set;}

		[InverseProperty("CreatedBy")]
		[JsonProperty("createdbyreconciliationsources")]
		[JsonPropertyName("createdbyreconciliationsources")]
		public ICollection<ReconciliationSource> CreatedByReconciliationSources {get;set;}

	}
}
